#!/usr/bin/env python3
"""
Crossflow Mobility — Pré-téléchargement du graphe OSMnx

Script autonome pour télécharger et mettre en cache le graphe routier
de Gennevilliers depuis OpenStreetMap.

Usage :
    python scripts/download_graph.py
    python scripts/download_graph.py --force   # Re-télécharge même si cache existant

Ce script peut être lancé avant de démarrer le serveur pour éviter
le délai de téléchargement au premier démarrage.
"""

import os
import sys
import argparse
import logging
import time

# ── Résolution des imports relatifs
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# ── Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("download_graph")

# ── Configuration (doit correspondre à graph_service.py)
PLACE_NAME = "Gennevilliers, Hauts-de-Seine, France"
NETWORK_TYPE = "drive"
CACHE_DIR = os.path.join(ROOT, "data")
CACHE_PICKLE = os.path.join(CACHE_DIR, "gennevilliers_graph.pkl")


def check_dependencies():
    """Vérifie que les dépendances nécessaires sont installées."""
    missing = []
    for pkg in ["osmnx", "networkx", "shapely", "geopandas"]:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)

    if missing:
        logger.error("Dépendances manquantes : %s", ", ".join(missing))
        logger.error("Lancez : pip install -r backend/requirements.txt")
        sys.exit(1)

    import osmnx
    import networkx
    logger.info(
        "Dépendances OK — OSMnx %s, NetworkX %s",
        osmnx.__version__,
        networkx.__version__,
    )


def download_graph(force: bool = False) -> bool:
    """
    Télécharge et met en cache le graphe routier.

    Args:
        force: Si True, re-télécharge même si le cache existe.

    Returns:
        True si succès, False sinon.
    """
    import pickle
    import osmnx as ox

    os.makedirs(CACHE_DIR, exist_ok=True)

    # ── Vérification du cache existant
    if not force and os.path.exists(CACHE_PICKLE):
        size_mb = os.path.getsize(CACHE_PICKLE) / (1024 * 1024)
        logger.info(
            "Cache déjà présent : %s (%.1f Mo)",
            CACHE_PICKLE,
            size_mb,
        )
        logger.info("Utilisez --force pour re-télécharger.")
        return True

    # ── Téléchargement
    logger.info("Connexion à OpenStreetMap...")
    logger.info("Zone : %s", PLACE_NAME)
    logger.info("Type de réseau : %s", NETWORK_TYPE)
    logger.info("Téléchargement en cours (peut prendre 30-60 secondes)...")

    t_start = time.time()
    try:
        graph = ox.graph_from_place(
            PLACE_NAME,
            network_type=NETWORK_TYPE,
            retain_all=False,
            truncate_by_edge=True,
        )
    except Exception as e:
        logger.error("Échec du téléchargement OSMnx : %s", e)
        logger.error("Vérifiez votre connexion Internet et le nom de la ville.")
        return False

    t_dl = time.time() - t_start
    logger.info(
        "Graphe téléchargé en %.1fs — %d nœuds, %d arêtes",
        t_dl,
        graph.number_of_nodes(),
        graph.number_of_edges(),
    )

    # ── Enrichissement
    logger.info("Calcul des vitesses et temps de trajet...")
    graph = ox.add_edge_speeds(graph)
    graph = ox.add_edge_travel_times(graph)

    # ── Sauvegarde pickle
    logger.info("Sauvegarde du cache : %s", CACHE_PICKLE)
    with open(CACHE_PICKLE, "wb") as f:
        pickle.dump(graph, f)

    size_mb = os.path.getsize(CACHE_PICKLE) / (1024 * 1024)
    t_total = time.time() - t_start
    logger.info(
        "Cache sauvegardé (%.1f Mo) en %.1f secondes au total.",
        size_mb,
        t_total,
    )

    # ── Stats rapides
    logger.info("─" * 50)
    logger.info("Statistiques du graphe :")
    logger.info("  Nœuds       : %d", graph.number_of_nodes())
    logger.info("  Arêtes      : %d", graph.number_of_edges())

    # Calcul longueur totale du réseau
    total_length = sum(
        d.get("length", 0)
        for u, v, d in graph.edges(data=True)
    )
    logger.info("  Réseau      : %.1f km", total_length / 1000)

    return True


def main():
    parser = argparse.ArgumentParser(
        description="Télécharge le graphe routier de Gennevilliers depuis OSMnx.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Force le re-téléchargement même si le cache existe déjà.",
    )
    args = parser.parse_args()

    logger.info("=" * 50)
    logger.info("  Crossflow Mobility — Téléchargement OSMnx")
    logger.info("=" * 50)

    check_dependencies()

    success = download_graph(force=args.force)

    if success:
        logger.info("─" * 50)
        logger.info("Prêt ! Vous pouvez maintenant lancer le serveur.")
        logger.info("  Linux/Mac  : ./start.sh")
        logger.info("  Windows    : start.bat")
        sys.exit(0)
    else:
        logger.error("Le téléchargement a échoué.")
        sys.exit(1)


if __name__ == "__main__":
    main()
