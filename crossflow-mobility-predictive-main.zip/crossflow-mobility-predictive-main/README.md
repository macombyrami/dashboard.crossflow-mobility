# Crossflow Mobility

Tableau de bord de simulation de trafic routier pour **Gennevilliers (Hauts-de-Seine)**.
Charge le réseau routier depuis OpenStreetMap, calcule des itinéraires Dijkstra et simule blocages, congestions et événements urbains.

---

## Aperçu

| Fonctionnalité | Description |
|---|---|
| Graphe OSM | Réseau routier réel de Gennevilliers via OSMnx |
| Calcul de route | Dijkstra pondéré (temps, distance, simulation) |
| Blocage de route | Retire un segment du graphe Dijkstra |
| Trafic | Coefficients ×1.2 / ×1.5 / ×2.0 sur le temps de trajet |
| Événements | Accident, travaux, manifestation, fermeture admin (rayon configurable) |
| Comparaison | Avant/après simulation sur le même itinéraire |
| Export GeoJSON | Téléchargement des segments affectés |
| Interface sombre | Dashboard React + Leaflet, tuiles CartoDB Dark |

---

## Prérequis

| Outil | Version minimale | Téléchargement |
|---|---|---|
| Python | 3.10 | https://python.org |
| Node.js | 18 | https://nodejs.org |
| pip | inclus avec Python | — |
| Connexion Internet | première utilisation | pour télécharger OSMnx |

---

## Installation et démarrage

### Option 1 — Script automatique (recommandé)

**Linux / macOS :**
```bash
cd crossflow-mobility
chmod +x start.sh
./start.sh
```

**Windows :**
```
start.bat
```

Le script :
1. Crée un virtualenv Python (`.venv/`)
2. Installe les dépendances Python (`requirements.txt`)
3. Installe les dépendances Node.js (`npm install`)
4. Télécharge le graphe OSMnx si absent (30–90 s, une seule fois)
5. Lance le backend FastAPI sur le port **8000**
6. Lance le frontend Vite sur le port **5173**

### Option 2 — Démarrage manuel

**Backend :**
```bash
cd crossflow-mobility
python -m venv .venv
source .venv/bin/activate          # Windows : .venv\Scripts\activate
pip install -r backend/requirements.txt

# Pré-télécharger le graphe (optionnel, le serveur le fait aussi au 1er appel)
python scripts/download_graph.py

PYTHONPATH=. uvicorn backend.main:app --reload --port 8000
```

**Frontend :**
```bash
cd crossflow-mobility/frontend
npm install
npm run dev
```

**Accès :**
- Application : http://localhost:5173
- Documentation API Swagger : http://localhost:8000/docs

---

## Utilisation

### 1. Charger le graphe
Au premier lancement, cliquez sur **"Charger le graphe"** dans la barre latérale.
Le téléchargement depuis OpenStreetMap prend 30–90 secondes selon la connexion.
Lors des lancements suivants, le cache local (`data/gennevilliers_graph.pkl`) est utilisé automatiquement.

### 2. Calculer un itinéraire
1. Cliquez sur **"Définir départ"** → cliquez sur la carte
2. Cliquez sur **"Définir arrivée"** → cliquez sur la carte
3. Cliquez sur **"Calculer l'itinéraire"**

### 3. Simuler du trafic
Dans l'onglet **Simulation** :

| Action | Mode | Comment |
|---|---|---|
| Bloquer une route | Clic "Bloquer une route" | Clic sur un segment de la carte |
| Ajouter du trafic | Choisir le niveau, clic "Appliquer trafic" | Clic sur un segment |
| Créer un événement | Choisir type + rayon, clic "Placer événement" | Clic sur la carte |

L'itinéraire se recalcule automatiquement après chaque modification.

### 4. Comparer avant/après
Dans l'onglet **Itinéraire**, cliquez sur **"Comparer avec simulation"** pour afficher simultanément l'itinéraire normal (vert) et simulé (rouge).

### 5. Réinitialiser
Clic sur **"Réinitialiser simulation"** pour effacer tous les blocages, trafics et événements.

---

## Architecture

```
crossflow-mobility/
├── backend/
│   ├── main.py                  # Application FastAPI, CORS, startup
│   ├── requirements.txt         # Dépendances Python
│   ├── models/
│   │   └── schemas.py           # Modèles Pydantic v2
│   ├── utils/
│   │   └── osm_utils.py         # Haversine, vitesses, poids Dijkstra
│   ├── services/
│   │   ├── graph_service.py     # OSMnx, cache pickle, export GeoJSON
│   │   ├── route_service.py     # Dijkstra sur MultiDiGraph → DiGraph
│   │   └── simulation_service.py# État de simulation (blocages, trafic, événements)
│   └── routers/
│       ├── graph.py             # /graph/*
│       ├── route.py             # /route/*
│       └── simulation.py        # /simulation/*
├── frontend/
│   ├── package.json
│   ├── vite.config.js           # Proxy /api → localhost:8000
│   ├── index.html
│   └── src/
│       ├── App.jsx              # Topbar + layout principal
│       ├── main.jsx             # Point d'entrée React
│       ├── services/
│       │   └── api.js           # Couche Axios vers le backend
│       ├── store/
│       │   └── useAppStore.js   # Store Zustand global
│       ├── components/
│       │   ├── Map/
│       │   │   ├── MapView.jsx        # Carte Leaflet principale
│       │   │   ├── GraphLayer.jsx     # Rendu réseau routier GeoJSON
│       │   │   ├── RouteLayer.jsx     # Rendu de l'itinéraire
│       │   │   └── MarkersLayer.jsx   # Marqueurs départ/arrivée/événements
│       │   ├── Sidebar/
│       │   │   ├── Sidebar.jsx        # Conteneur avec onglets
│       │   │   ├── RoutePanel.jsx     # Onglet itinéraire
│       │   │   ├── SimulationPanel.jsx# Onglet simulation
│       │   │   └── StatsPanel.jsx     # Onglet analytique
│       │   └── UI/
│       │       └── Notification.jsx   # Toast notifications
│       └── styles/
│           └── global.css       # Thème sombre, variables CSS
├── scripts/
│   └── download_graph.py        # Pré-téléchargement OSMnx standalone
├── data/
│   └── .gitkeep                 # Cache pickle (non versionné)
├── start.sh                     # Démarrage Linux/macOS
├── start.bat                    # Démarrage Windows
└── .gitignore
```

---

## API REST

### Graphe

| Méthode | Endpoint | Description |
|---|---|---|
| `POST` | `/graph/load-gennevilliers` | Charge le graphe (paramètre `?force_reload=true`) |
| `GET` | `/graph/stats` | Statistiques du graphe chargé |
| `GET` | `/graph/nodes` | GeoJSON des nœuds |
| `GET` | `/graph/edges` | GeoJSON des segments (`?status_filter=all\|slow\|blocked`) |

### Itinéraire

| Méthode | Endpoint | Description |
|---|---|---|
| `POST` | `/route/calculate` | Calcule l'itinéraire Dijkstra |
| `POST` | `/route/compare` | Retourne les routes normale et simulée |

### Simulation

| Méthode | Endpoint | Description |
|---|---|---|
| `GET` | `/simulation/state` | État courant (blocages, trafic, événements) |
| `POST` | `/simulation/block-road` | Bloque un segment |
| `POST` | `/simulation/unblock-road` | Débloque un segment |
| `POST` | `/simulation/add-traffic` | Applique un niveau de trafic |
| `POST` | `/simulation/remove-traffic` | Retire le trafic d'un segment |
| `POST` | `/simulation/add-event` | Crée un événement localisé |
| `POST` | `/simulation/reset` | Réinitialise toute la simulation |
| `GET` | `/simulation/analytics` | Métriques analytiques globales |

Documentation interactive complète : **http://localhost:8000/docs**

---

## Logique de calcul

### Poids Dijkstra

```
weight = (travel_time_s × traffic_coefficient) + event_penalty_s
```

- `travel_time_s` — temps de trajet de base calculé par OSMnx
- `traffic_coefficient` — `1.0` (normal) / `1.2` (léger) / `1.5` (moyen) / `2.0` (dense)
- `event_penalty_s` — `300 s` (accident) / `120 s` (travaux) / `180 s` (manifestation) / `600 s` (administratif)
- Segments bloqués : weight = `∞` (exclus de Dijkstra)

### Détection de l'impact d'un événement

La distance entre le centre géométrique d'un segment et le point de l'événement est calculée par la formule **haversine**. Tous les segments dont le centre se trouve dans le rayon configuré (défaut : 200 m) reçoivent la pénalité.

---

## Limitations connues

1. **Feux de signalisation OSM** — La couverture des nœuds `highway=traffic_signals` dans OSM pour Gennevilliers peut être partielle. Le comptage affiché sous-estime le nombre réel de feux.

2. **Sens uniques** — Les sens uniques OSM sont respectés. Certains contournements peuvent sembler non intuitifs.

3. **Mises à jour OSM** — Le graphe est mis en cache après le premier téléchargement. Pour utiliser les données OSM les plus récentes, relancez avec `--force` ou `?force_reload=true`.

4. **Performance** — La conversion MultiDiGraph → DiGraph (pour Dijkstra) est recalculée à chaque requête de route. Pour des volumes élevés de requêtes simultanées, un cache de graphe pondéré serait nécessaire.

5. **Persistance** — La simulation est en mémoire. Elle est réinitialisée au redémarrage du serveur.

---

## Pistes d'amélioration

- [ ] **Isochrones** — zones accessibles en N minutes depuis un point
- [ ] **Import CSV** — chargement d'événements depuis un fichier externe
- [ ] **Historique** — replay temporel de scénarios de simulation
- [ ] **Multi-zones** — support d'autres communes au-delà de Gennevilliers
- [ ] **Persistence** — sauvegarde de l'état de simulation en base (SQLite)
- [ ] **WebSockets** — mise à jour temps réel de la carte (push)
- [ ] **Mode piéton/vélo** — support `network_type = "walk" | "bike"`
- [ ] **GTFS** — superposition des lignes de transport en commun

---

## Stack technique

| Composant | Technologie |
|---|---|
| Backend | Python 3.10+ / FastAPI 0.111 / Uvicorn |
| Graphe | NetworkX 3.3 (Dijkstra) |
| Géodonnées | OSMnx 1.9 / Shapely / GeoPandas |
| Frontend | React 18 / Vite 5 |
| État frontend | Zustand 4 |
| Carte | Leaflet 1.9 / React-Leaflet 4 |
| Tuiles | CartoDB Dark Matter |
| HTTP client | Axios |

---

## Licence

Projet éducatif. Données cartographiques © [OpenStreetMap contributors](https://www.openstreetmap.org/copyright) — licence ODbL.
