"""
Crossflow Mobility — Pydantic schemas
Tous les modèles de requête/réponse de l'API.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum


# ─────────────────────────────────────────────────
# Enums
# ─────────────────────────────────────────────────

class EdgeStatus(str, Enum):
    NORMAL = "normal"
    SLOW = "slow"
    BLOCKED = "blocked"


class TrafficLevel(str, Enum):
    LIGHT = "light"       # x1.2
    MEDIUM = "medium"     # x1.5
    HEAVY = "heavy"       # x2.0
    BLOCKED = "blocked"   # infini


class EventType(str, Enum):
    ACCIDENT = "accident"
    WORKS = "works"
    DEMONSTRATION = "demonstration"
    ADMINISTRATIVE = "administrative"


# ─────────────────────────────────────────────────
# Geo primitives
# ─────────────────────────────────────────────────

class LatLng(BaseModel):
    lat: float = Field(..., description="Latitude WGS84")
    lng: float = Field(..., description="Longitude WGS84")


# ─────────────────────────────────────────────────
# Graph
# ─────────────────────────────────────────────────

class NodeData(BaseModel):
    id: str
    lat: float
    lng: float
    is_traffic_signal: bool = False
    is_crossing: bool = False
    street_count: int = 0


class EdgeData(BaseModel):
    id: str
    u: str
    v: str
    name: Optional[str] = None
    highway: str = "unclassified"
    length: float = 0.0           # mètres
    speed_kph: float = 50.0       # km/h
    travel_time: float = 0.0      # secondes
    oneway: bool = False
    status: EdgeStatus = EdgeStatus.NORMAL
    traffic_coefficient: float = 1.0
    event_penalty: float = 0.0
    geometry: List[List[float]] = Field(
        default_factory=list,
        description="Liste de [lat, lng] pour le tracé de l'edge"
    )


class GraphStats(BaseModel):
    node_count: int
    edge_count: int
    intersection_count: int
    traffic_signal_count: int
    place_name: str
    loaded: bool
    cache_used: bool = False


class GraphLoadResponse(BaseModel):
    success: bool
    message: str
    stats: Optional[GraphStats] = None


# ─────────────────────────────────────────────────
# Route
# ─────────────────────────────────────────────────

class RouteRequest(BaseModel):
    start: LatLng
    end: LatLng
    weight_mode: str = Field(
        default="travel_time",
        description="Critère de pondération : travel_time | length"
    )


class RouteSegment(BaseModel):
    edge_id: str
    name: Optional[str] = None
    length: float
    travel_time: float
    status: EdgeStatus
    geometry: List[List[float]]


class RouteResponse(BaseModel):
    success: bool
    message: str = ""
    path_node_ids: List[str] = Field(default_factory=list)
    segments: List[RouteSegment] = Field(default_factory=list)
    total_distance_m: float = 0.0
    total_time_s: float = 0.0
    geometry: List[List[float]] = Field(
        default_factory=list,
        description="Coordonnées [lat, lng] concaténées pour affichage direct"
    )
    start_node_id: str = ""
    end_node_id: str = ""


# ─────────────────────────────────────────────────
# Simulation
# ─────────────────────────────────────────────────

class BlockRoadRequest(BaseModel):
    edge_id: str = Field(..., description="ID de l'edge à bloquer (format: u_v_key)")


class UnblockRoadRequest(BaseModel):
    edge_id: str


class TrafficRequest(BaseModel):
    edge_id: str
    level: TrafficLevel = TrafficLevel.MEDIUM


class EventRequest(BaseModel):
    center: LatLng
    radius_m: float = Field(default=200.0, description="Rayon d'impact en mètres")
    event_type: EventType = EventType.ACCIDENT
    label: Optional[str] = None


class SimulationStateResponse(BaseModel):
    blocked_edges: List[str] = Field(default_factory=list)
    traffic_edges: Dict[str, float] = Field(
        default_factory=dict,
        description="edge_id -> coefficient multiplicateur"
    )
    events: List[Dict[str, Any]] = Field(default_factory=list)
    affected_edges: List[str] = Field(
        default_factory=list,
        description="Tous les edges affectés (blocage + trafic + événements)"
    )


class SimulationActionResponse(BaseModel):
    success: bool
    message: str
    state: Optional[SimulationStateResponse] = None


# ─────────────────────────────────────────────────
# Analytics
# ─────────────────────────────────────────────────

class AnalyticsResponse(BaseModel):
    total_roads: int
    total_intersections: int
    blocked_roads: int
    slow_roads: int
    traffic_signals: int
    active_events: int
    average_speed_kph: float
    network_coverage_km: float
