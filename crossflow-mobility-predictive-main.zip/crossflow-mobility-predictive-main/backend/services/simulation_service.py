"""
Crossflow Mobility — SimulationService
Gestion de l'état de simulation : blocages, trafic, événements.

Concept :
  SimulationService maintient un état mutable qui surcharge le graphe de base.
  Les modifications n'altèrent pas le graphe OSMnx persisté sur disque.
  Elles sont appliquées dynamiquement lors de chaque calcul de route.

État de simulation :
  - blocked_edges        : set d'edge_ids → retire ces edges du graphe Dijkstra
  - traffic_edges        : dict edge_id → coefficient (1.0 = normal, 2.0 = trafic fort)
  - events               : liste d'événements avec métadonnées
  - event_edge_penalties : dict edge_id → pénalité (secondes ajoutées au poids)
"""

import logging
import uuid
from datetime import datetime
from typing import Dict, Set, List, Any, Optional

logger = logging.getLogger(__name__)

# Coefficients de trafic par niveau
TRAFFIC_COEFFICIENTS = {
    "light": 1.2,
    "medium": 1.5,
    "heavy": 2.0,
    "blocked": float("inf"),
}

# Pénalités en secondes par type d'événement
EVENT_PENALTIES = {
    "accident": 300.0,
    "works": 120.0,
    "demonstration": 180.0,
    "administrative": 600.0,
}


class SimulationService:
    """
    Service de simulation de trafic.
    Thread-safe pour une utilisation en environnement web mono-processus.
    """

    def __init__(self, graph_service):
        self.graph_service = graph_service
        self._blocked_edges: Set[str] = set()
        self._traffic_edges: Dict[str, float] = {}        # edge_id → coefficient
        self._events: List[Dict[str, Any]] = []
        self._event_edge_penalties: Dict[str, float] = {}  # edge_id → pénalité cumulée

    # ─────────────────────────────────────────────
    # Blocage de routes
    # ─────────────────────────────────────────────

    def block_road(self, edge_id: str) -> Dict[str, Any]:
        """
        Bloque complètement un segment de route.
        Le segment est retiré du graphe lors des calculs Dijkstra.
        """
        if not self._edge_exists(edge_id):
            return {"success": False, "message": f"Edge introuvable : {edge_id}"}

        self._blocked_edges.add(edge_id)
        # Synchroniser le statut dans edges_data
        self._set_edge_status(edge_id, "blocked")
        logger.info("Route bloquée : %s", edge_id)
        return {"success": True, "message": f"Route bloquée : {edge_id}"}

    def unblock_road(self, edge_id: str) -> Dict[str, Any]:
        """Débloque un segment de route précédemment bloqué."""
        self._blocked_edges.discard(edge_id)
        self._set_edge_status(edge_id, self._compute_visual_status(edge_id))
        logger.info("Route débloquée : %s", edge_id)
        return {"success": True, "message": f"Route débloquée : {edge_id}"}

    # ─────────────────────────────────────────────
    # Trafic
    # ─────────────────────────────────────────────

    def add_traffic(self, edge_id: str, level: str) -> Dict[str, Any]:
        """
        Applique un coefficient de congestion à un segment.

        Niveaux : light (x1.2) | medium (x1.5) | heavy (x2.0) | blocked (inf)
        """
        if not self._edge_exists(edge_id):
            return {"success": False, "message": f"Edge introuvable : {edge_id}"}

        if level == "blocked":
            return self.block_road(edge_id)

        coeff = TRAFFIC_COEFFICIENTS.get(level, 1.0)
        self._traffic_edges[edge_id] = coeff
        self._set_edge_status(edge_id, "slow" if coeff > 1.0 else "normal")

        logger.info("Trafic appliqué sur %s : niveau=%s (x%.1f)", edge_id, level, coeff)
        return {
            "success": True,
            "message": f"Trafic {level} (x{coeff}) appliqué sur {edge_id}",
        }

    def remove_traffic(self, edge_id: str) -> Dict[str, Any]:
        """Supprime le coefficient de trafic d'un edge."""
        self._traffic_edges.pop(edge_id, None)
        self._set_edge_status(edge_id, self._compute_visual_status(edge_id))
        return {"success": True, "message": f"Trafic retiré de {edge_id}"}

    # ─────────────────────────────────────────────
    # Événements
    # ─────────────────────────────────────────────

    def add_event(
        self,
        center_lat: float,
        center_lng: float,
        radius_m: float,
        event_type: str,
        label: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Crée un événement localisé et applique des pénalités aux edges proches.

        L'événement affecte tous les edges dont le centre géométrique
        se trouve dans le rayon donné.
        """
        from backend.utils.osm_utils import edges_within_radius

        gs = self.graph_service
        if not gs.is_loaded:
            return {"success": False, "message": "Le graphe n'est pas chargé."}

        # Trouver les edges impactés
        affected_ids = edges_within_radius(
            gs.edges_data, center_lat, center_lng, radius_m
        )

        penalty = EVENT_PENALTIES.get(event_type, 120.0)

        # Appliquer les pénalités
        for eid in affected_ids:
            self._event_edge_penalties[eid] = (
                self._event_edge_penalties.get(eid, 0.0) + penalty
            )
            if eid not in self._blocked_edges:
                self._set_edge_status(eid, "slow")

        # Enregistrer l'événement
        event = {
            "id": str(uuid.uuid4()),
            "type": event_type,
            "label": label or event_type.capitalize(),
            "center": {"lat": center_lat, "lng": center_lng},
            "radius_m": radius_m,
            "penalty_s": penalty,
            "affected_edges": affected_ids,
            "created_at": datetime.utcnow().isoformat(),
        }
        self._events.append(event)

        logger.info(
            "Événement %s créé : %d edges impactés (pénalité +%.0fs)",
            event_type, len(affected_ids), penalty
        )
        return {
            "success": True,
            "message": f"Événement {event_type} créé ({len(affected_ids)} routes affectées)",
            "event": event,
        }

    # ─────────────────────────────────────────────
    # Reset
    # ─────────────────────────────────────────────

    def reset(self) -> Dict[str, Any]:
        """
        Réinitialise complètement la simulation.
        Remet tous les statuts d'edges à 'normal'.
        """
        # Remettre les statuts visuels
        gs = self.graph_service
        if gs.is_loaded:
            for edge in gs.edges_data.values():
                edge["status"] = "normal"
                edge["traffic_coefficient"] = 1.0
                edge["event_penalty"] = 0.0

        self._blocked_edges.clear()
        self._traffic_edges.clear()
        self._events.clear()
        self._event_edge_penalties.clear()

        logger.info("Simulation réinitialisée.")
        return {"success": True, "message": "Simulation réinitialisée."}

    # ─────────────────────────────────────────────
    # État courant
    # ─────────────────────────────────────────────

    def get_state(self) -> Dict[str, Any]:
        """Retourne l'état complet de la simulation (pour l'API)."""
        all_affected = (
            self._blocked_edges
            | set(self._traffic_edges.keys())
            | set(self._event_edge_penalties.keys())
        )
        return {
            "blocked_edges": list(self._blocked_edges),
            "traffic_edges": dict(self._traffic_edges),
            "events": list(self._events),
            "affected_edges": list(all_affected),
        }

    def get_state_dict(self) -> Dict[str, Any]:
        """Version interne incluant les pénalités d'événements."""
        return {
            "blocked_edges": list(self._blocked_edges),
            "traffic_edges": dict(self._traffic_edges),
            "event_edge_penalties": dict(self._event_edge_penalties),
            "events": list(self._events),
        }

    # ─────────────────────────────────────────────
    # Analytics
    # ─────────────────────────────────────────────

    def get_analytics(self) -> Dict[str, Any]:
        """Calcule les métriques analytiques globales."""
        gs = self.graph_service
        if not gs.is_loaded:
            return {}

        edges = gs.edges_data
        total_length = sum(e.get("length", 0) for e in edges.values())
        speeds = [e.get("speed_kph", 50) for e in edges.values() if e.get("speed_kph", 0) > 0]
        avg_speed = sum(speeds) / len(speeds) if speeds else 0.0

        traffic_signals = sum(
            1 for n in gs.nodes_data.values() if n.get("is_traffic_signal")
        )
        intersections = sum(
            1 for n in gs.nodes_data.values() if n.get("street_count", 0) >= 3
        )

        return {
            "total_roads": len(edges),
            "total_intersections": intersections,
            "blocked_roads": len(self._blocked_edges),
            "slow_roads": len(self._traffic_edges),
            "traffic_signals": traffic_signals,
            "active_events": len(self._events),
            "average_speed_kph": round(avg_speed, 1),
            "network_coverage_km": round(total_length / 1000, 2),
        }

    # ─────────────────────────────────────────────
    # Helpers internes
    # ─────────────────────────────────────────────

    def _edge_exists(self, edge_id: str) -> bool:
        return edge_id in self.graph_service.edges_data

    def _set_edge_status(self, edge_id: str, status: str):
        """Met à jour le statut visuel d'un edge dans edges_data."""
        edata = self.graph_service.edges_data.get(edge_id)
        if edata:
            edata["status"] = status
            edata["traffic_coefficient"] = self._traffic_edges.get(edge_id, 1.0)
            edata["event_penalty"] = self._event_edge_penalties.get(edge_id, 0.0)

    def _compute_visual_status(self, edge_id: str) -> str:
        """Détermine le statut visuel d'un edge selon l'état de simulation."""
        if edge_id in self._blocked_edges:
            return "blocked"
        if edge_id in self._traffic_edges or edge_id in self._event_edge_penalties:
            return "slow"
        return "normal"


# ─────────────────────────────────────────────────
# Instance globale
# ─────────────────────────────────────────────────

simulation_service: Optional[SimulationService] = None


def init_simulation_service(graph_service) -> SimulationService:
    global simulation_service
    simulation_service = SimulationService(graph_service)
    return simulation_service
