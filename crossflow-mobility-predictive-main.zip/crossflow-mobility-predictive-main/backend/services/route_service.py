"""
Crossflow Mobility — RouteService
Calcul d'itinéraire optimal via Dijkstra (NetworkX).

Architecture du calcul :
  1. Trouver le nœud le plus proche du point de départ
  2. Trouver le nœud le plus proche du point d'arrivée
  3. Construire le graphe pondéré selon l'état de simulation courant
  4. Lancer Dijkstra (nx.dijkstra_path)
  5. Reconstruire la géométrie et les statistiques du trajet

Extension future :
  La méthode _build_weighted_graph() peut être remplacée par
  A* ou d'autres algorithmes sans modifier l'interface publique.
"""

import logging
from typing import Dict, Any, List, Optional, Tuple

import networkx as nx

logger = logging.getLogger(__name__)


class RouteService:
    """
    Service de calcul d'itinéraire.
    Dépend de GraphService (graphe de base) et SimulationService (état courant).
    """

    def __init__(self, graph_service, simulation_service):
        self.graph_service = graph_service
        self.simulation_service = simulation_service

    # ─────────────────────────────────────────────
    # Interface publique
    # ─────────────────────────────────────────────

    def calculate_route(
        self,
        start_lat: float,
        start_lng: float,
        end_lat: float,
        end_lng: float,
        weight_mode: str = "travel_time",
    ) -> Dict[str, Any]:
        """
        Calcule l'itinéraire optimal entre deux points géographiques.

        Paramètres :
            start_lat/lng : coordonnées du point de départ
            end_lat/lng   : coordonnées du point d'arrivée
            weight_mode   : "travel_time" (défaut) ou "length"

        Retourne un dict compatible avec RouteResponse.
        """
        gs = self.graph_service
        ss = self.simulation_service

        if not gs.is_loaded:
            return self._error("Le graphe n'est pas chargé. Appelez /graph/load-gennevilliers d'abord.")

        # ── 1. Nœuds les plus proches
        start_node, start_dist = gs.find_nearest_node(start_lat, start_lng)
        end_node, end_dist = gs.find_nearest_node(end_lat, end_lng)

        if start_node is None or end_node is None:
            return self._error("Impossible de trouver un nœud proche du point sélectionné.")

        if start_node == end_node:
            return self._error("Le point de départ et d'arrivée sont au même nœud du graphe.")

        logger.info(
            "Calcul de route : %s → %s (mode: %s)",
            start_node, end_node, weight_mode
        )

        # ── 2. Construction du graphe pondéré
        weighted_graph = self._build_weighted_graph(
            gs.graph, gs.edges_data, ss.get_state_dict(), weight_mode
        )

        # ── 3. Dijkstra
        try:
            path_nodes = nx.dijkstra_path(
                weighted_graph,
                source=int(start_node),
                target=int(end_node),
                weight="weight",
            )
        except nx.NetworkXNoPath:
            return self._error(
                "Aucun chemin trouvé. Les routes bloquées isolent peut-être les deux points."
            )
        except nx.NodeNotFound as e:
            return self._error(f"Nœud introuvable dans le graphe : {e}")
        except Exception as e:
            logger.exception("Erreur Dijkstra : %s", e)
            return self._error(f"Erreur de calcul : {str(e)}")

        # ── 4. Reconstruction du trajet
        return self._build_route_response(
            path_nodes, gs, ss, weight_mode, start_node, end_node
        )

    # ─────────────────────────────────────────────
    # Construction du graphe pondéré
    # ─────────────────────────────────────────────

    def _build_weighted_graph(
        self,
        base_graph: nx.MultiDiGraph,
        edges_data: Dict[str, Any],
        sim_state: Dict,
        weight_mode: str,
    ) -> nx.DiGraph:
        """
        Crée un DiGraph simple (non-multi) avec les poids effectifs.
        Les edges bloqués sont ignorés (non ajoutés).

        Utilise les données de simulation pour modifier les poids :
          - blocked_edges   : poids infini → ignoré
          - traffic_edges   : coefficient multiplicateur
          - event_edges     : pénalité additionnelle
        """
        from backend.utils.osm_utils import compute_edge_weight

        blocked = set(sim_state.get("blocked_edges", []))
        traffic = sim_state.get("traffic_edges", {})   # edge_id → coefficient
        event_penalties = sim_state.get("event_edge_penalties", {})  # edge_id → pénalité

        G = nx.DiGraph()
        G.add_nodes_from(base_graph.nodes())

        # Pour un MultiDiGraph, on garde l'edge avec le poids le plus faible
        # entre u et v si plusieurs parallèles existent.
        best_edges: Dict[Tuple, Tuple] = {}  # (u, v) → (weight, edge_id, key)

        for u, v, key, data in base_graph.edges(data=True, keys=True):
            edge_id = f"{u}_{v}_{key}"

            # Edge bloqué → on saute
            if edge_id in blocked:
                continue

            # Données enrichies depuis edges_data
            edata = edges_data.get(edge_id, {})
            travel_time = edata.get("travel_time", data.get("travel_time", 60.0))
            length = edata.get("length", data.get("length", 100.0))
            status = edata.get("status", "normal")

            coeff = traffic.get(edge_id, 1.0)
            penalty = event_penalties.get(edge_id, 0.0)

            weight = compute_edge_weight(
                travel_time=float(travel_time or 60.0),
                status=status,
                traffic_coefficient=coeff,
                event_penalty=penalty,
                weight_mode=weight_mode,
                length=float(length or 100.0),
            )

            if weight == float("inf"):
                continue

            pair = (u, v)
            if pair not in best_edges or weight < best_edges[pair][0]:
                best_edges[pair] = (weight, edge_id, key)

        for (u, v), (weight, edge_id, key) in best_edges.items():
            G.add_edge(u, v, weight=weight, edge_id=edge_id, key=key)

        return G

    # ─────────────────────────────────────────────
    # Reconstruction de la réponse
    # ─────────────────────────────────────────────

    def _build_route_response(
        self,
        path_nodes: List[int],
        gs,
        ss,
        weight_mode: str,
        start_node_id: str,
        end_node_id: str,
    ) -> Dict[str, Any]:
        """
        Construit la réponse complète depuis la liste de nœuds du chemin.
        Reconstruit les segments et la géométrie.
        """
        segments = []
        total_distance = 0.0
        total_time = 0.0
        full_geometry = []
        path_node_ids = [str(n) for n in path_nodes]

        sim_state = ss.get_state_dict()
        blocked = set(sim_state.get("blocked_edges", []))
        traffic = sim_state.get("traffic_edges", {})
        event_penalties = sim_state.get("event_edge_penalties", {})

        for i in range(len(path_nodes) - 1):
            u = path_nodes[i]
            v = path_nodes[i + 1]

            # Trouver le meilleur edge entre u et v (le moins coûteux non bloqué)
            edge_id, edata = self._find_best_edge(u, v, gs, blocked)
            if edata is None:
                continue

            coeff = traffic.get(edge_id, 1.0)
            penalty = event_penalties.get(edge_id, 0.0)
            travel_time = edata["travel_time"] * coeff + penalty
            length = edata["length"]

            total_distance += length
            total_time += travel_time

            # Géométrie
            geom = edata.get("geometry", [])
            if geom:
                if full_geometry and full_geometry[-1] == geom[0]:
                    full_geometry.extend(geom[1:])
                else:
                    full_geometry.extend(geom)

            # Statut visuel du segment
            status = edata.get("status", "normal")
            if edge_id in blocked:
                status = "blocked"
            elif coeff > 1.0 or penalty > 0:
                status = "slow"

            segments.append({
                "edge_id": edge_id,
                "name": edata.get("name"),
                "length": round(length, 2),
                "travel_time": round(travel_time, 2),
                "status": status,
                "geometry": geom,
            })

        return {
            "success": True,
            "message": f"Itinéraire calculé : {len(segments)} segments",
            "path_node_ids": path_node_ids,
            "segments": segments,
            "total_distance_m": round(total_distance, 2),
            "total_time_s": round(total_time, 2),
            "geometry": full_geometry,
            "start_node_id": start_node_id,
            "end_node_id": end_node_id,
        }

    def _find_best_edge(
        self,
        u: int,
        v: int,
        gs,
        blocked: set,
    ) -> Tuple[Optional[str], Optional[Dict]]:
        """
        Parmi tous les edges parallèles u→v, retourne celui avec le travel_time
        le plus faible qui n'est pas bloqué.
        """
        best_id = None
        best_data = None
        best_time = float("inf")

        # Cherche les edges u→v dans le MultiDiGraph
        if gs.graph.has_edge(u, v):
            for key in gs.graph[u][v]:
                eid = f"{u}_{v}_{key}"
                if eid in blocked:
                    continue
                edata = gs.edges_data.get(eid)
                if edata and edata.get("travel_time", float("inf")) < best_time:
                    best_time = edata["travel_time"]
                    best_id = eid
                    best_data = edata

        return best_id, best_data

    # ─────────────────────────────────────────────
    # Helpers
    # ─────────────────────────────────────────────

    @staticmethod
    def _error(msg: str) -> Dict[str, Any]:
        logger.warning("RouteService erreur : %s", msg)
        return {
            "success": False,
            "message": msg,
            "path_node_ids": [],
            "segments": [],
            "total_distance_m": 0.0,
            "total_time_s": 0.0,
            "geometry": [],
            "start_node_id": "",
            "end_node_id": "",
        }


# ─────────────────────────────────────────────────
# Instance (injectée via main.py avec les services)
# ─────────────────────────────────────────────────

route_service: Optional[RouteService] = None


def init_route_service(graph_service, simulation_service) -> RouteService:
    global route_service
    route_service = RouteService(graph_service, simulation_service)
    return route_service
