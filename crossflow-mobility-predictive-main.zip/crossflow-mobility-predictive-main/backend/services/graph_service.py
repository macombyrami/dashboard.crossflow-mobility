"""
Crossflow Mobility — GraphService
Charge, met en cache et expose le graphe routier de Gennevilliers via OSMnx.

Architecture :
  - OSMnx télécharge le graphe depuis OpenStreetMap
  - Le graphe est enrichi (vitesses, temps de trajet)
  - Il est mis en cache localement (pickle) pour éviter le re-téléchargement
  - Les données nodes/edges sont exposées sous forme sérialisable (dict Python)

Limite documentée :
  Les feux de signalisation (traffic_signals) sont extraits des nœuds OSM
  ayant le tag highway=traffic_signals. Leur nombre dépend de la couverture
  OSM de Gennevilliers, qui peut être partielle.
"""

import os
import pickle
import logging
import json
from typing import Optional, Dict, Any, Tuple

import networkx as nx

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────

PLACE_NAME = "Gennevilliers, Hauts-de-Seine, France"
CACHE_DIR = "data"
CACHE_PICKLE = os.path.join(CACHE_DIR, "gennevilliers_graph.pkl")
CACHE_STATS = os.path.join(CACHE_DIR, "gennevilliers_stats.json")

# Types de voies inclus dans le graphe routier (circulation motorisée)
NETWORK_TYPE = "drive"


class GraphService:
    """
    Service central gérant le graphe routier de Gennevilliers.
    Singleton instancié au démarrage de l'application FastAPI.
    """

    def __init__(self):
        self.graph: Optional[nx.MultiDiGraph] = None
        self.nodes_data: Dict[str, Any] = {}    # node_id (str) -> dict
        self.edges_data: Dict[str, Any] = {}    # edge_id (str) -> dict
        self._loaded = False
        self._cache_used = False
        os.makedirs(CACHE_DIR, exist_ok=True)

    # ─────────────────────────────────────────────
    # Propriétés publiques
    # ─────────────────────────────────────────────

    @property
    def is_loaded(self) -> bool:
        return self._loaded and self.graph is not None

    # ─────────────────────────────────────────────
    # Chargement principal
    # ─────────────────────────────────────────────

    def load(self, force_reload: bool = False) -> Dict[str, Any]:
        """
        Charge le graphe routier.
        1. Vérifie le cache pickle local.
        2. Si absent ou force_reload=True → télécharge via OSMnx.
        3. Enrichit le graphe (vitesses, temps de trajet).
        4. Construit les structures de données internes.

        Retourne un dict avec les stats du graphe chargé.
        """
        try:
            import osmnx as ox
        except ImportError:
            raise RuntimeError(
                "OSMnx n'est pas installé. Lancez : pip install osmnx"
            )

        # ── Tentative de chargement depuis le cache
        if not force_reload and os.path.exists(CACHE_PICKLE):
            logger.info("Chargement du graphe depuis le cache : %s", CACHE_PICKLE)
            try:
                with open(CACHE_PICKLE, "rb") as f:
                    self.graph = pickle.load(f)
                self._cache_used = True
                logger.info("Cache chargé avec succès (%d nœuds, %d arêtes)",
                            self.graph.number_of_nodes(),
                            self.graph.number_of_edges())
            except Exception as e:
                logger.warning("Cache corrompu (%s), re-téléchargement...", e)
                self.graph = None
                self._cache_used = False

        # ── Téléchargement OSMnx si nécessaire
        if self.graph is None:
            logger.info("Téléchargement du graphe OSMnx pour : %s", PLACE_NAME)
            self.graph = ox.graph_from_place(
                PLACE_NAME,
                network_type=NETWORK_TYPE,
                retain_all=False,
                truncate_by_edge=True,
            )
            # Enrichissement OSMnx : vitesses par défaut + temps de trajet
            self.graph = ox.add_edge_speeds(self.graph)
            self.graph = ox.add_edge_travel_times(self.graph)
            self._cache_used = False

            # Sauvegarde du cache
            logger.info("Sauvegarde du cache : %s", CACHE_PICKLE)
            with open(CACHE_PICKLE, "wb") as f:
                pickle.dump(self.graph, f)

        # ── Construction des structures internes
        self._build_nodes()
        self._build_edges()
        self._loaded = True

        stats = self._compute_stats()
        logger.info("Graphe prêt : %s", stats)
        return stats

    # ─────────────────────────────────────────────
    # Construction des données internes
    # ─────────────────────────────────────────────

    def _build_nodes(self):
        """
        Construit nodes_data depuis le graphe NetworkX.
        Chaque nœud correspond à une intersection ou extrémité de segment.
        """
        from backend.utils.osm_utils import haversine_distance
        self.nodes_data = {}

        for node_id, data in self.graph.nodes(data=True):
            highway_tag = data.get("highway", "")
            ref_tag = data.get("ref", "")

            self.nodes_data[str(node_id)] = {
                "id": str(node_id),
                "lat": data.get("y", 0.0),
                "lng": data.get("x", 0.0),
                "is_traffic_signal": highway_tag == "traffic_signals",
                "is_crossing": highway_tag == "crossing",
                "street_count": data.get("street_count", 0),
                "ref": ref_tag,
            }

    def _build_edges(self):
        """
        Construit edges_data depuis le graphe NetworkX.
        Chaque edge correspond à un segment de rue entre deux nœuds.
        """
        from backend.utils.osm_utils import (
            get_edge_speed,
            compute_travel_time,
            normalize_highway,
            normalize_name,
        )

        self.edges_data = {}

        for u, v, key, data in self.graph.edges(data=True, keys=True):
            edge_id = f"{u}_{v}_{key}"

            # ── Géométrie
            geometry = self._extract_geometry(u, v, data)

            # ── Vitesse et temps de trajet
            speed_kph = get_edge_speed(data)
            length = float(data.get("length", 0.0))

            # Préférer le travel_time calculé par OSMnx si disponible
            osmnx_time = data.get("travel_time", None)
            if osmnx_time and float(osmnx_time) > 0:
                travel_time = float(osmnx_time)
            else:
                travel_time = compute_travel_time(length, speed_kph)

            self.edges_data[edge_id] = {
                "id": edge_id,
                "u": str(u),
                "v": str(v),
                "key": key,
                "name": normalize_name(data.get("name")),
                "highway": normalize_highway(data.get("highway", "unclassified")),
                "length": round(length, 2),
                "speed_kph": round(speed_kph, 1),
                "travel_time": round(travel_time, 2),
                "oneway": bool(data.get("oneway", False)),
                "status": "normal",
                "traffic_coefficient": 1.0,
                "event_penalty": 0.0,
                "geometry": geometry,
            }

    def _extract_geometry(self, u: int, v: int, data: Dict) -> list:
        """
        Extrait la géométrie d'un edge sous forme de liste [[lat, lng], ...].
        Utilise la géométrie Shapely si disponible, sinon ligne droite.
        """
        try:
            from shapely.geometry import mapping
            geom = data.get("geometry")
            if geom is not None:
                coords = list(geom.coords)
                return [[round(c[1], 7), round(c[0], 7)] for c in coords]
        except Exception:
            pass

        # Fallback : ligne droite entre u et v
        u_data = self.graph.nodes.get(u, {})
        v_data = self.graph.nodes.get(v, {})
        return [
            [round(u_data.get("y", 0), 7), round(u_data.get("x", 0), 7)],
            [round(v_data.get("y", 0), 7), round(v_data.get("x", 0), 7)],
        ]

    # ─────────────────────────────────────────────
    # Stats
    # ─────────────────────────────────────────────

    def _compute_stats(self) -> Dict[str, Any]:
        """Calcule les statistiques du graphe chargé."""
        traffic_signals = sum(
            1 for n in self.nodes_data.values() if n.get("is_traffic_signal")
        )
        intersections = sum(
            1 for n in self.nodes_data.values() if n.get("street_count", 0) >= 3
        )
        return {
            "node_count": len(self.nodes_data),
            "edge_count": len(self.edges_data),
            "intersection_count": intersections,
            "traffic_signal_count": traffic_signals,
            "place_name": PLACE_NAME,
            "loaded": True,
            "cache_used": self._cache_used,
        }

    def get_stats(self) -> Dict[str, Any]:
        """Retourne les stats publiques du graphe."""
        if not self.is_loaded:
            return {
                "node_count": 0,
                "edge_count": 0,
                "intersection_count": 0,
                "traffic_signal_count": 0,
                "place_name": PLACE_NAME,
                "loaded": False,
                "cache_used": False,
            }
        return self._compute_stats()

    # ─────────────────────────────────────────────
    # Accès aux données
    # ─────────────────────────────────────────────

    def get_node(self, node_id: str) -> Optional[Dict]:
        return self.nodes_data.get(str(node_id))

    def get_edge(self, edge_id: str) -> Optional[Dict]:
        return self.edges_data.get(edge_id)

    def find_nearest_node(self, lat: float, lng: float) -> Tuple[str, float]:
        """
        Trouve le nœud du graphe le plus proche du point (lat, lng).
        Utilise OSMnx get_nearest_node ou calcul haversine direct.

        Retourne (node_id, distance_m).
        """
        if not self.is_loaded:
            raise RuntimeError("Le graphe n'est pas chargé.")

        try:
            import osmnx as ox
            node_id = ox.nearest_nodes(self.graph, X=lng, Y=lat)
            node_data = self.nodes_data.get(str(node_id), {})
            from backend.utils.osm_utils import haversine_distance
            dist = haversine_distance(lat, lng, node_data.get("lat", 0), node_data.get("lng", 0))
            return str(node_id), round(dist, 2)
        except Exception as e:
            logger.warning("OSMnx nearest_nodes échoué (%s), fallback haversine", e)
            return self._find_nearest_node_fallback(lat, lng)

    def _find_nearest_node_fallback(self, lat: float, lng: float) -> Tuple[str, float]:
        """Fallback pur Python si OSMnx échoue."""
        from backend.utils.osm_utils import haversine_distance
        best_id = None
        best_dist = float("inf")
        for nid, ndata in self.nodes_data.items():
            d = haversine_distance(lat, lng, ndata["lat"], ndata["lng"])
            if d < best_dist:
                best_dist = d
                best_id = nid
        return best_id, round(best_dist, 2)

    # ─────────────────────────────────────────────
    # Export GeoJSON
    # ─────────────────────────────────────────────

    def export_nodes_geojson(self) -> Dict:
        """Exporte les nœuds au format GeoJSON FeatureCollection."""
        features = []
        for nid, n in self.nodes_data.items():
            features.append({
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [n["lng"], n["lat"]]},
                "properties": {k: v for k, v in n.items() if k not in ("lat", "lng")},
            })
        return {"type": "FeatureCollection", "features": features}

    def export_edges_geojson(self, edge_ids: Optional[list] = None) -> Dict:
        """
        Exporte les edges au format GeoJSON FeatureCollection.
        Si edge_ids est fourni, n'exporte que ces edges.
        """
        edges = self.edges_data
        if edge_ids is not None:
            edges = {eid: edges[eid] for eid in edge_ids if eid in edges}

        features = []
        for eid, e in edges.items():
            geom = e.get("geometry", [])
            if len(geom) < 2:
                continue
            coords = [[c[1], c[0]] for c in geom]  # GeoJSON = [lng, lat]
            features.append({
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": coords},
                "properties": {k: v for k, v in e.items() if k != "geometry"},
            })
        return {"type": "FeatureCollection", "features": features}


# ─────────────────────────────────────────────────
# Instance globale (singleton applicatif)
# ─────────────────────────────────────────────────

graph_service = GraphService()
