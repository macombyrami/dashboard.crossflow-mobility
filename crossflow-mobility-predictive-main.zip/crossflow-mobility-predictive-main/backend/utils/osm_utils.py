"""
Crossflow Mobility — Utilitaires OSM
Fonctions helpers pour la manipulation des données OpenStreetMap.
"""

import math
from typing import List, Tuple, Optional, Dict, Any


# ─────────────────────────────────────────────────
# Constantes vitesse par type de voie (km/h)
# Source : recommandations OSM + Code de la Route FR
# ─────────────────────────────────────────────────

DEFAULT_SPEEDS: Dict[str, float] = {
    "motorway": 130.0,
    "motorway_link": 80.0,
    "trunk": 110.0,
    "trunk_link": 70.0,
    "primary": 80.0,
    "primary_link": 50.0,
    "secondary": 70.0,
    "secondary_link": 50.0,
    "tertiary": 50.0,
    "tertiary_link": 30.0,
    "residential": 30.0,
    "living_street": 20.0,
    "service": 20.0,
    "unclassified": 40.0,
    "road": 40.0,
    "cycleway": 15.0,
    "footway": 5.0,
    "pedestrian": 5.0,
    "path": 10.0,
    "track": 20.0,
}

# Coefficients de pénalité par type d'événement
EVENT_PENALTIES: Dict[str, float] = {
    "accident": 300.0,       # +5 min
    "works": 120.0,          # +2 min
    "demonstration": 180.0,  # +3 min
    "administrative": 600.0, # +10 min — fermeture totale probable
}

# Coefficients de trafic
TRAFFIC_COEFFICIENTS: Dict[str, float] = {
    "light": 1.2,
    "medium": 1.5,
    "heavy": 2.0,
    "blocked": float("inf"),
}


# ─────────────────────────────────────────────────
# Fonctions géographiques
# ─────────────────────────────────────────────────

def haversine_distance(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    """
    Calcule la distance haversine entre deux points (mètres).
    Plus précis que la distance euclidienne en coordonnées géographiques.
    """
    R = 6_371_000  # rayon terrestre en mètres
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lng2 - lng1)

    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


def parse_maxspeed(maxspeed_str: Any) -> Optional[float]:
    """
    Parse le tag OSM maxspeed en float (km/h).
    Gère les formats : "50", "50 mph", "FR:urban", "walk", etc.
    Retourne None si non parsable.
    """
    if maxspeed_str is None:
        return None

    s = str(maxspeed_str).strip().lower()

    # Cas spéciaux OSM
    special_values = {
        "walk": 7.0,
        "none": 130.0,
        "fr:urban": 50.0,
        "fr:rural": 80.0,
        "fr:motorway": 130.0,
        "fr:living_street": 20.0,
    }
    if s in special_values:
        return special_values[s]

    # Valeur MPH → km/h
    if "mph" in s:
        try:
            return float(s.replace("mph", "").strip()) * 1.60934
        except ValueError:
            return None

    # Valeur numérique directe
    try:
        return float(s)
    except ValueError:
        return None


def get_edge_speed(data: Dict[str, Any]) -> float:
    """
    Détermine la vitesse d'un edge en km/h.
    Priorité : maxspeed OSM > speed_kph OSMnx > vitesse par type de voie > défaut.
    """
    # 1. Utilise speed_kph calculé par OSMnx (déjà intégré)
    if "speed_kph" in data and data["speed_kph"]:
        try:
            speed = float(data["speed_kph"])
            if speed > 0:
                return speed
        except (ValueError, TypeError):
            pass

    # 2. Parse le maxspeed OSM brut
    maxspeed = parse_maxspeed(data.get("maxspeed"))
    if maxspeed and maxspeed > 0:
        return maxspeed

    # 3. Fallback par type de route
    highway = data.get("highway", "unclassified")
    if isinstance(highway, list):
        highway = highway[0] if highway else "unclassified"
    return DEFAULT_SPEEDS.get(str(highway), 40.0)


def compute_travel_time(length_m: float, speed_kph: float) -> float:
    """
    Calcule le temps de trajet en secondes.
    travel_time = (distance / vitesse) converti en secondes.
    """
    if speed_kph <= 0:
        speed_kph = 40.0
    speed_mps = speed_kph / 3.6  # m/s
    return length_m / speed_mps


def compute_edge_weight(
    travel_time: float,
    status: str,
    traffic_coefficient: float = 1.0,
    event_penalty: float = 0.0,
    weight_mode: str = "travel_time",
    length: float = 0.0,
) -> float:
    """
    Calcule le poids effectif d'un edge pour Dijkstra.

    Formule :
        weight = (travel_time * traffic_coefficient) + event_penalty
    Si blocked : weight = inf (edge retiré du calcul).
    """
    if status == "blocked":
        return float("inf")

    if weight_mode == "length":
        base = length
    else:
        base = travel_time

    return (base * traffic_coefficient) + event_penalty


def normalize_highway(highway: Any) -> str:
    """Normalise le tag highway (peut être une liste dans OSMnx)."""
    if isinstance(highway, list):
        return highway[0] if highway else "unclassified"
    return str(highway) if highway else "unclassified"


def normalize_name(name: Any) -> Optional[str]:
    """Normalise le nom de rue (peut être une liste)."""
    if isinstance(name, list):
        return name[0] if name else None
    return str(name) if name else None


def edges_within_radius(
    edges_data: Dict[str, Any],
    center_lat: float,
    center_lng: float,
    radius_m: float,
) -> List[str]:
    """
    Retourne les IDs des edges dont le centre géométrique
    est dans un rayon donné (en mètres) du point centre.
    """
    affected = []
    for edge_id, edge in edges_data.items():
        geometry = edge.get("geometry", [])
        if not geometry:
            continue
        # Centre de l'edge = milieu de la géométrie
        mid_idx = len(geometry) // 2
        mid = geometry[mid_idx]
        dist = haversine_distance(center_lat, center_lng, mid[0], mid[1])
        if dist <= radius_m:
            affected.append(edge_id)
    return affected
