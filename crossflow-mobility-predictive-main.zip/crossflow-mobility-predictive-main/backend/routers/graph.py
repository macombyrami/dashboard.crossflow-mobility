"""
Crossflow Mobility — Router /graph
Endpoints de chargement et consultation du graphe routier.
"""

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import JSONResponse

from backend.services.graph_service import graph_service
from backend.models.schemas import GraphLoadResponse, GraphStats

router = APIRouter(prefix="/graph", tags=["graph"])


@router.post("/load-gennevilliers", response_model=GraphLoadResponse)
def load_gennevilliers(force_reload: bool = Query(default=False)):
    """
    Charge le graphe routier de Gennevilliers depuis OpenStreetMap via OSMnx.

    - Premier appel : télécharge les données (~30-90s selon connexion)
    - Appels suivants : charge depuis le cache local (< 5s)
    - force_reload=true : force le re-téléchargement depuis OSM
    """
    try:
        stats = graph_service.load(force_reload=force_reload)
        return GraphLoadResponse(
            success=True,
            message="Graphe chargé avec succès",
            stats=GraphStats(**stats),
        )
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erreur lors du chargement : {str(e)}")


@router.get("/stats", response_model=GraphStats)
def get_graph_stats():
    """Retourne les statistiques du graphe courant."""
    return GraphStats(**graph_service.get_stats())


@router.get("/nodes")
def get_nodes(
    traffic_signals_only: bool = Query(default=False),
    intersections_only: bool = Query(default=False),
):
    """
    Retourne les nœuds du graphe au format GeoJSON.

    Filtres optionnels :
    - traffic_signals_only : uniquement les feux de signalisation OSM
    - intersections_only   : uniquement les intersections (≥3 rues)
    """
    if not graph_service.is_loaded:
        raise HTTPException(status_code=409, detail="Graphe non chargé. POST /graph/load-gennevilliers d'abord.")

    nodes = graph_service.nodes_data.values()

    if traffic_signals_only:
        nodes = [n for n in nodes if n.get("is_traffic_signal")]
    elif intersections_only:
        nodes = [n for n in nodes if n.get("street_count", 0) >= 3]

    features = [
        {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [n["lng"], n["lat"]]},
            "properties": {k: v for k, v in n.items() if k not in ("lat", "lng")},
        }
        for n in nodes
    ]
    return {"type": "FeatureCollection", "features": features}


@router.get("/edges")
def get_edges(status_filter: str = Query(default="all")):
    """
    Retourne les edges du graphe au format GeoJSON.

    status_filter : all | normal | slow | blocked
    """
    if not graph_service.is_loaded:
        raise HTTPException(status_code=409, detail="Graphe non chargé.")

    edges = graph_service.edges_data.values()

    if status_filter != "all":
        edges = [e for e in edges if e.get("status") == status_filter]

    return graph_service.export_edges_geojson(
        [e["id"] for e in edges] if status_filter != "all" else None
    )


@router.get("/export/edges-geojson")
def export_affected_edges_geojson():
    """
    Exporte au format GeoJSON uniquement les segments impactés
    (bloqués ou ralentis) pour analyse externe.
    """
    if not graph_service.is_loaded:
        raise HTTPException(status_code=409, detail="Graphe non chargé.")

    affected = [
        eid for eid, e in graph_service.edges_data.items()
        if e.get("status") in ("slow", "blocked")
    ]
    return graph_service.export_edges_geojson(affected)
