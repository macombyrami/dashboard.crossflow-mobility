"""
Crossflow Mobility — Router /simulation
Endpoints de gestion de la simulation de trafic.
"""

from fastapi import APIRouter, HTTPException

from backend.models.schemas import (
    BlockRoadRequest,
    UnblockRoadRequest,
    TrafficRequest,
    EventRequest,
    SimulationStateResponse,
    SimulationActionResponse,
    AnalyticsResponse,
)
from backend.services.graph_service import graph_service
import backend.services.simulation_service as _sim_module

router = APIRouter(prefix="/simulation", tags=["simulation"])


def _get_sim():
    """Accès dynamique au service — évite le problème de capture None à l'import."""
    svc = _sim_module.simulation_service
    if svc is None:
        raise HTTPException(status_code=503, detail="SimulationService non initialisé.")
    return svc


def _check_loaded():
    if not graph_service.is_loaded:
        raise HTTPException(
            status_code=409,
            detail="Graphe non chargé. POST /graph/load-gennevilliers d'abord."
        )


# ─────────────────────────────────────────────────
# État
# ─────────────────────────────────────────────────

@router.get("/state", response_model=SimulationStateResponse)
def get_simulation_state():
    """Retourne l'état complet de la simulation en cours."""
    _check_loaded()
    state = _get_sim().get_state()
    return SimulationStateResponse(
        blocked_edges=state["blocked_edges"],
        traffic_edges=state["traffic_edges"],
        events=state["events"],
        affected_edges=state["affected_edges"],
    )


@router.post("/reset", response_model=SimulationActionResponse)
def reset_simulation():
    """
    Réinitialise complètement la simulation.
    Supprime tous les blocages, niveaux de trafic et événements.
    """
    _check_loaded()
    result = _get_sim().reset()
    return SimulationActionResponse(
        success=result["success"],
        message=result["message"],
        state=SimulationStateResponse(
            blocked_edges=[],
            traffic_edges={},
            events=[],
            affected_edges=[],
        ),
    )


# ─────────────────────────────────────────────────
# Blocage de routes
# ─────────────────────────────────────────────────

@router.post("/block-road", response_model=SimulationActionResponse)
def block_road(request: BlockRoadRequest):
    """
    Bloque complètement un segment de route identifié par son edge_id.
    L'edge est retiré du graphe pour les calculs Dijkstra suivants.

    L'edge_id est au format "u_v_key" (ex: "123456789_987654321_0").
    Il peut être récupéré via GET /graph/edges.
    """
    _check_loaded()
    result = _get_sim().block_road(request.edge_id)
    if not result["success"]:
        raise HTTPException(status_code=404, detail=result["message"])
    return SimulationActionResponse(
        success=True,
        message=result["message"],
        state=_get_state_response(),
    )


@router.post("/unblock-road", response_model=SimulationActionResponse)
def unblock_road(request: UnblockRoadRequest):
    """Débloque un segment de route précédemment bloqué."""
    _check_loaded()
    result = _get_sim().unblock_road(request.edge_id)
    return SimulationActionResponse(
        success=True,
        message=result["message"],
        state=_get_state_response(),
    )


# ─────────────────────────────────────────────────
# Trafic
# ─────────────────────────────────────────────────

@router.post("/add-traffic", response_model=SimulationActionResponse)
def add_traffic(request: TrafficRequest):
    """
    Applique un niveau de congestion sur un segment.

    Niveaux disponibles :
    - light  : x1.2 — trafic léger
    - medium : x1.5 — trafic moyen
    - heavy  : x2.0 — trafic fort
    - blocked : fermeture complète

    Le coefficient multiplicateur est appliqué au temps de trajet
    dans le calcul de pondération Dijkstra.
    """
    _check_loaded()
    result = _get_sim().add_traffic(request.edge_id, request.level.value)
    if not result["success"]:
        raise HTTPException(status_code=404, detail=result["message"])
    return SimulationActionResponse(
        success=True,
        message=result["message"],
        state=_get_state_response(),
    )


@router.post("/remove-traffic", response_model=SimulationActionResponse)
def remove_traffic(request: UnblockRoadRequest):
    """Supprime le coefficient de trafic d'un segment."""
    _check_loaded()
    result = _get_sim().remove_traffic(request.edge_id)
    return SimulationActionResponse(
        success=True,
        message=result["message"],
        state=_get_state_response(),
    )


# ─────────────────────────────────────────────────
# Événements
# ─────────────────────────────────────────────────

@router.post("/add-event", response_model=SimulationActionResponse)
def add_event(request: EventRequest):
    """
    Crée un événement localisé affectant toutes les routes dans un rayon donné.

    Types d'événements et pénalités par défaut :
    - accident       : +300s
    - works          : +120s
    - demonstration  : +180s
    - administrative : +600s (fermeture probable)

    La pénalité est ajoutée au poids des edges impactés dans Dijkstra.
    """
    _check_loaded()
    result = _get_sim().add_event(
        center_lat=request.center.lat,
        center_lng=request.center.lng,
        radius_m=request.radius_m,
        event_type=request.event_type.value,
        label=request.label,
    )
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    return SimulationActionResponse(
        success=True,
        message=result["message"],
        state=_get_state_response(),
    )


# ─────────────────────────────────────────────────
# Analytics
# ─────────────────────────────────────────────────

@router.get("/analytics", response_model=AnalyticsResponse)
def get_analytics():
    """
    Retourne les métriques analytiques globales du réseau et de la simulation.

    Inclut : routes totales, intersections, routes bloquées/lentes,
    feux de signalisation, événements actifs, vitesse moyenne, couverture km.
    """
    _check_loaded()
    data = _get_sim().get_analytics()
    if not data:
        raise HTTPException(status_code=409, detail="Graphe non chargé.")
    return AnalyticsResponse(**data)


# ─────────────────────────────────────────────────
# Helper
# ─────────────────────────────────────────────────

def _get_state_response() -> SimulationStateResponse:
    state = _get_sim().get_state()
    return SimulationStateResponse(
        blocked_edges=state["blocked_edges"],
        traffic_edges=state["traffic_edges"],
        events=state["events"],
        affected_edges=state["affected_edges"],
    )
