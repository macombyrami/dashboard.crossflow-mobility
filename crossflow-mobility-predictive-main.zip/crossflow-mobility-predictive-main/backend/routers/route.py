"""
Crossflow Mobility — Router /route
Endpoints de calcul d'itinéraire.
"""

from fastapi import APIRouter, HTTPException

from backend.models.schemas import RouteRequest, RouteResponse, RouteSegment, EdgeStatus
from backend.services.graph_service import graph_service
import backend.services.simulation_service as _sim_module

router = APIRouter(prefix="/route", tags=["route"])


def _get_sim_svc():
    """Accès dynamique au service — évite le problème de capture None à l'import."""
    svc = _sim_module.simulation_service
    if svc is None:
        raise HTTPException(status_code=503, detail="SimulationService non initialisé.")
    return svc


def _get_route_service():
    """Lazy import pour éviter les imports circulaires."""
    from backend.services.route_service import route_service
    if route_service is None:
        raise HTTPException(status_code=503, detail="RouteService non initialisé.")
    return route_service


@router.post("/calculate", response_model=RouteResponse)
def calculate_route(request: RouteRequest):
    """
    Calcule l'itinéraire optimal entre deux points géographiques.

    Le calcul prend en compte l'état courant de la simulation :
    - routes bloquées exclues
    - coefficients de trafic appliqués
    - pénalités d'événements intégrées

    Corps de requête :
        {
          "start": {"lat": 48.924, "lng": 2.294},
          "end":   {"lat": 48.933, "lng": 2.305},
          "weight_mode": "travel_time"  // ou "length"
        }
    """
    if not graph_service.is_loaded:
        raise HTTPException(
            status_code=409,
            detail="Graphe non chargé. Appelez POST /graph/load-gennevilliers d'abord."
        )

    rs = _get_route_service()
    result = rs.calculate_route(
        start_lat=request.start.lat,
        start_lng=request.start.lng,
        end_lat=request.end.lat,
        end_lng=request.end.lng,
        weight_mode=request.weight_mode,
    )

    if not result["success"]:
        raise HTTPException(status_code=404, detail=result["message"])

    # Conversion des segments en modèles Pydantic
    segments = [
        RouteSegment(
            edge_id=s["edge_id"],
            name=s.get("name"),
            length=s["length"],
            travel_time=s["travel_time"],
            status=EdgeStatus(s["status"]),
            geometry=s["geometry"],
        )
        for s in result["segments"]
    ]

    return RouteResponse(
        success=True,
        message=result["message"],
        path_node_ids=result["path_node_ids"],
        segments=segments,
        total_distance_m=result["total_distance_m"],
        total_time_s=result["total_time_s"],
        geometry=result["geometry"],
        start_node_id=result["start_node_id"],
        end_node_id=result["end_node_id"],
    )


@router.post("/compare")
def compare_routes(request: RouteRequest):
    """
    Compare l'itinéraire en conditions normales vs conditions de simulation actuelles.
    Utile pour visualiser l'impact des blocages/congestions.
    """
    if not graph_service.is_loaded:
        raise HTTPException(status_code=409, detail="Graphe non chargé.")

    rs = _get_route_service()
    ss = _get_sim_svc()

    # Route avec simulation active
    route_simulated = rs.calculate_route(
        request.start.lat, request.start.lng,
        request.end.lat, request.end.lng,
        weight_mode=request.weight_mode,
    )

    # Route sans simulation (état neutre temporaire)
    original_state = ss.get_state_dict()
    ss.reset()
    route_normal = rs.calculate_route(
        request.start.lat, request.start.lng,
        request.end.lat, request.end.lng,
        weight_mode=request.weight_mode,
    )

    # Restaurer l'état de simulation
    # Note : un reset complet est fait ici pour simplicité.
    # Une implémentation plus robuste sauvegarderait et restaurerait l'état.
    for eid in original_state.get("blocked_edges", []):
        ss.block_road(eid)
    for eid, coeff in original_state.get("traffic_edges", {}).items():
        # Re-appliquer les coefficients de trafic
        level = "medium"
        if coeff >= 2.0:
            level = "heavy"
        elif coeff <= 1.2:
            level = "light"
        ss.add_traffic(eid, level)

    if not route_normal["success"] or not route_simulated["success"]:
        return {
            "normal": route_normal,
            "simulated": route_simulated,
            "delta": None,
        }

    # Calcul des deltas
    dist_delta = route_simulated["total_distance_m"] - route_normal["total_distance_m"]
    time_delta = route_simulated["total_time_s"] - route_normal["total_time_s"]

    normal_edges = {s["edge_id"] for s in route_normal["segments"]}
    simulated_edges = {s["edge_id"] for s in route_simulated["segments"]}
    avoided = list(normal_edges - simulated_edges)
    added = list(simulated_edges - normal_edges)

    return {
        "normal": {
            "total_distance_m": route_normal["total_distance_m"],
            "total_time_s": route_normal["total_time_s"],
            "geometry": route_normal["geometry"],
        },
        "simulated": {
            "total_distance_m": route_simulated["total_distance_m"],
            "total_time_s": route_simulated["total_time_s"],
            "geometry": route_simulated["geometry"],
        },
        "delta": {
            "distance_m": round(dist_delta, 2),
            "time_s": round(time_delta, 2),
            "avoided_edges": avoided,
            "added_edges": added,
        },
    }
