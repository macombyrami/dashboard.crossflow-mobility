"""
Crossflow Mobility — Backend FastAPI
Point d'entrée principal de l'application.

Démarrage :
    cd backend
    uvicorn main:app --reload --port 8000

Ou depuis la racine :
    uvicorn backend.main:app --reload --port 8000
"""

import logging
import sys
import os

# Ajouter le répertoire parent au PYTHONPATH pour les imports relatifs
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from backend.services.graph_service import graph_service
from backend.services.simulation_service import init_simulation_service
from backend.services.route_service import init_route_service
from backend.routers import graph, route, simulation

# ─────────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s : %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger("crossflow")


# ─────────────────────────────────────────────────
# Application FastAPI
# ─────────────────────────────────────────────────

app = FastAPI(
    title="Crossflow Mobility API",
    description=(
        "API de simulation de trafic urbain pour Gennevilliers. "
        "Basée sur OpenStreetMap, NetworkX (Dijkstra) et OSMnx."
    ),
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# ─────────────────────────────────────────────────
# CORS — autoriser le frontend React local
# ─────────────────────────────────────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─────────────────────────────────────────────────
# Événements de cycle de vie
# ─────────────────────────────────────────────────

@app.on_event("startup")
async def startup_event():
    """
    Initialise les services au démarrage.
    Le graphe OSMnx n'est PAS chargé automatiquement
    (peut prendre 30-90s). L'utilisateur doit appeler
    POST /graph/load-gennevilliers.

    Si un cache existe, il sera chargé automatiquement
    lors du premier appel.
    """
    logger.info("=== Crossflow Mobility Backend démarré ===")

    # Initialiser simulation_service avec le graphe
    sim_svc = init_simulation_service(graph_service)
    logger.info("SimulationService initialisé.")

    # Initialiser route_service avec graphe + simulation
    init_route_service(graph_service, sim_svc)
    logger.info("RouteService initialisé.")

    # Tentative de chargement auto depuis le cache (silencieuse)
    import os
    cache_path = os.path.join("data", "gennevilliers_graph.pkl")
    if os.path.exists(cache_path):
        logger.info("Cache OSMnx détecté, chargement automatique...")
        try:
            graph_service.load(force_reload=False)
            # Re-init simulation avec le graphe chargé
            sim_svc.__init__(graph_service)
            logger.info("Graphe chargé depuis le cache avec succès.")
        except Exception as e:
            logger.warning("Chargement auto du cache échoué : %s", e)
    else:
        logger.info("Aucun cache trouvé. Appelez POST /graph/load-gennevilliers.")


@app.on_event("shutdown")
async def shutdown_event():
    logger.info("=== Crossflow Mobility Backend arrêté ===")


# ─────────────────────────────────────────────────
# Routers
# ─────────────────────────────────────────────────

app.include_router(graph.router)
app.include_router(route.router)
app.include_router(simulation.router)


# ─────────────────────────────────────────────────
# Endpoints de base
# ─────────────────────────────────────────────────

@app.get("/health", tags=["system"])
def health_check():
    """Vérifie que l'API est opérationnelle."""
    return {
        "status": "ok",
        "version": "1.0.0",
        "graph_loaded": graph_service.is_loaded,
        "node_count": len(graph_service.nodes_data),
        "edge_count": len(graph_service.edges_data),
    }


@app.get("/", tags=["system"])
def root():
    """Racine de l'API."""
    return {
        "name": "Crossflow Mobility API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health",
    }


@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    logger.exception("Erreur non gérée : %s", exc)
    return JSONResponse(
        status_code=500,
        content={"detail": f"Erreur interne : {str(exc)}"},
    )
