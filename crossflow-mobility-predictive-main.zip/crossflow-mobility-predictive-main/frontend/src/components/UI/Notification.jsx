/**
 * Notification flottante (toast) en bas à droite.
 */

import { X, CheckCircle, AlertCircle, Info } from 'lucide-react'

const ICONS = {
  success: CheckCircle,
  error: AlertCircle,
  info: Info,
}

export default function Notification({ type = 'info', message, onClose }) {
  const Icon = ICONS[type] || Info

  return (
    <div className={`notification notification-${type}`}>
      <Icon size={16} className="notif-icon" />
      <span className="notif-message">{message}</span>
      <button className="notif-close" onClick={onClose} aria-label="Fermer">
        <X size={14} />
      </button>
    </div>
  )
}
