/**
 * Crossflow Mobility — MapView
 * Composant principal de la carte Leaflet.
 * Gère les clics utilisateur selon le mode d'interaction actif.
 */

import { useEffect, useRef } from 'react'
import {
  MapContainer,
  TileLayer,
  useMapEvents,
} from 'react-leaflet'
import 'leaflet/dist/leaflet.css'

import useAppStore, { INTERACTION_MODE } from '../../store/useAppStore'
import GraphLayer from './GraphLayer'
import RouteLayer from './RouteLayer'
import MarkersLayer from './MarkersLayer'

// Centre géographique de Gennevilliers
const GENNEVILLIERS_CENTER = [48.9239, 2.2939]
const DEFAULT_ZOOM = 14

/**
 * Composant interne qui capte les événements de la carte.
 */
function MapEventHandler() {
  const {
    interactionMode,
    setStartPoint,
    setEndPoint,
    blockRoad,
    addTraffic,
    addEvent,
  } = useAppStore()

  useMapEvents({
    click(e) {
      const latlng = { lat: e.latlng.lat, lng: e.latlng.lng }

      switch (interactionMode) {
        case INTERACTION_MODE.SELECT_START:
          setStartPoint(latlng)
          useAppStore.getState().setInteractionMode(INTERACTION_MODE.SELECT_END)
          break

        case INTERACTION_MODE.SELECT_END:
          setEndPoint(latlng)
          useAppStore.getState().setInteractionMode(INTERACTION_MODE.NONE)
          break

        case INTERACTION_MODE.ADD_EVENT:
          addEvent(latlng)
          useAppStore.getState().setInteractionMode(INTERACTION_MODE.NONE)
          break

        default:
          break
      }
    },
  })

  return null
}

/**
 * Curseur personnalisé selon le mode d'interaction.
 */
function useCursorStyle(mapRef) {
  const interactionMode = useAppStore((s) => s.interactionMode)

  useEffect(() => {
    const container = mapRef.current?.getContainer()
    if (!container) return

    const cursors = {
      [INTERACTION_MODE.SELECT_START]: 'crosshair',
      [INTERACTION_MODE.SELECT_END]: 'crosshair',
      [INTERACTION_MODE.BLOCK_ROAD]: 'not-allowed',
      [INTERACTION_MODE.ADD_TRAFFIC]: 'pointer',
      [INTERACTION_MODE.ADD_EVENT]: 'cell',
      [INTERACTION_MODE.NONE]: '',
    }
    container.style.cursor = cursors[interactionMode] || ''
  }, [interactionMode, mapRef])
}

function CursorManager({ mapRef }) {
  useCursorStyle(mapRef)
  return null
}

export default function MapView() {
  const mapRef = useRef(null)

  return (
    <div className="map-wrapper">
      <MapContainer
        center={GENNEVILLIERS_CENTER}
        zoom={DEFAULT_ZOOM}
        className="leaflet-map"
        ref={mapRef}
        preferCanvas={true}
        zoomControl={true}
      >
        {/* Tuiles sombres — style dashboard mobilité */}
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://carto.com/">CARTO</a> &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          maxZoom={19}
        />

        {/* Gestionnaire d'événements carte */}
        <MapEventHandler />
        <CursorManager mapRef={mapRef} />

        {/* Couches de données */}
        <GraphLayer />
        <RouteLayer />
        <MarkersLayer />
      </MapContainer>

      {/* Légende */}
      <MapLegend />

      {/* Indicateur de mode */}
      <InteractionModeIndicator />
    </div>
  )
}

function MapLegend() {
  return (
    <div className="map-legend">
      <div className="legend-title">Légende</div>
      <div className="legend-item">
        <span className="legend-line legend-normal" />
        <span>Route normale</span>
      </div>
      <div className="legend-item">
        <span className="legend-line legend-route" />
        <span>Itinéraire</span>
      </div>
      <div className="legend-item">
        <span className="legend-line legend-slow" />
        <span>Trafic ralenti</span>
      </div>
      <div className="legend-item">
        <span className="legend-line legend-blocked" />
        <span>Route bloquée</span>
      </div>
      <div className="legend-item">
        <span className="legend-dot legend-signal" />
        <span>Feu de signalisation</span>
      </div>
    </div>
  )
}

function InteractionModeIndicator() {
  const mode = useAppStore((s) => s.interactionMode)

  const labels = {
    [INTERACTION_MODE.SELECT_START]: '📍 Cliquez pour définir le départ',
    [INTERACTION_MODE.SELECT_END]: '🏁 Cliquez pour définir l\'arrivée',
    [INTERACTION_MODE.BLOCK_ROAD]: '🚫 Cliquez sur un segment pour le bloquer',
    [INTERACTION_MODE.ADD_TRAFFIC]: '🚗 Cliquez sur un segment pour ajouter du trafic',
    [INTERACTION_MODE.ADD_EVENT]: '⚠️ Cliquez sur la carte pour placer l\'événement',
  }

  if (!labels[mode]) return null

  return (
    <div className="interaction-indicator">
      {labels[mode]}
    </div>
  )
}
