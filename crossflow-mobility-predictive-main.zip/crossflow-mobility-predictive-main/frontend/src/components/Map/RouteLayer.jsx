/**
 * Crossflow Mobility — RouteLayer
 * Affiche l'itinéraire calculé (et la comparaison avant/après).
 */

import { Polyline, Tooltip } from 'react-leaflet'
import useAppStore from '../../store/useAppStore'

// Couleurs d'itinéraire
const COLOR_ROUTE = '#63b3ed'         // bleu — itinéraire courant
const COLOR_ROUTE_NORMAL = '#68d391'  // vert — itinéraire avant simulation
const COLOR_ROUTE_SIMULATED = '#fc8181' // rouge clair — itinéraire avec simulation

export default function RouteLayer() {
  const route = useAppStore((s) => s.route)
  const showComparison = useAppStore((s) => s.showComparison)
  const routeNormal = useAppStore((s) => s.routeNormal)
  const routeSimulated = useAppStore((s) => s.routeSimulated)

  if (showComparison && routeNormal && routeSimulated) {
    return (
      <>
        {/* Itinéraire normal (fond vert) */}
        <Polyline
          positions={routeNormal.geometry || []}
          pathOptions={{
            color: COLOR_ROUTE_NORMAL,
            weight: 5,
            opacity: 0.7,
            dashArray: '8 4',
          }}
        >
          <Tooltip sticky>
            <strong>Itinéraire normal</strong><br />
            {formatDist(routeNormal.total_distance_m)} — {formatTime(routeNormal.total_time_s)}
          </Tooltip>
        </Polyline>

        {/* Itinéraire simulé (rouge) */}
        <Polyline
          positions={routeSimulated.geometry || []}
          pathOptions={{
            color: COLOR_ROUTE_SIMULATED,
            weight: 5,
            opacity: 0.9,
          }}
        >
          <Tooltip sticky>
            <strong>Itinéraire simulé</strong><br />
            {formatDist(routeSimulated.total_distance_m)} — {formatTime(routeSimulated.total_time_s)}
          </Tooltip>
        </Polyline>
      </>
    )
  }

  if (!route || !route.geometry?.length) return null

  return (
    <>
      {/* Ombre portée */}
      <Polyline
        positions={route.geometry}
        pathOptions={{
          color: '#1a365d',
          weight: 8,
          opacity: 0.4,
        }}
      />

      {/* Tracé principal */}
      <Polyline
        positions={route.geometry}
        pathOptions={{
          color: COLOR_ROUTE,
          weight: 5,
          opacity: 0.95,
          lineCap: 'round',
          lineJoin: 'round',
        }}
      >
        <Tooltip sticky>
          <strong>Itinéraire</strong><br />
          {formatDist(route.total_distance_m)} — {formatTime(route.total_time_s)}
        </Tooltip>
      </Polyline>
    </>
  )
}

// ─────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────

function formatDist(m) {
  if (!m) return '—'
  return m >= 1000 ? `${(m / 1000).toFixed(2)} km` : `${Math.round(m)} m`
}

function formatTime(s) {
  if (!s) return '—'
  const min = Math.round(s / 60)
  if (min < 60) return `${min} min`
  const h = Math.floor(min / 60)
  const rem = min % 60
  return `${h}h ${rem}min`
}
