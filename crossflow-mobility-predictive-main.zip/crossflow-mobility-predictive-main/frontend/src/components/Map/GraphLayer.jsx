/**
 * Crossflow Mobility — GraphLayer
 * Affiche le réseau routier (edges + nœuds) depuis le GeoJSON du backend.
 *
 * Couleurs par statut :
 *   normal  → #4a5568 (gris discret)
 *   slow    → #ed8936 (orange)
 *   blocked → #e53e3e (rouge)
 *
 * Les edges cliquables permettent l'interaction (blocage, trafic).
 */

import { useMemo, useCallback } from 'react'
import { GeoJSON, CircleMarker, Tooltip } from 'react-leaflet'
import L from 'leaflet'

import useAppStore, { INTERACTION_MODE } from '../../store/useAppStore'

// ─────────────────────────────────────────────────
// Couleurs
// ─────────────────────────────────────────────────

const EDGE_COLORS = {
  normal: '#4a5568',
  slow: '#ed8936',
  blocked: '#e53e3e',
}

const EDGE_WEIGHT = {
  normal: 1.5,
  slow: 2.5,
  blocked: 3,
}

const SIGNAL_COLOR = '#68d391'   // vert clair pour les feux
const INTERSECTION_COLOR = '#a0aec0'
const CROSSING_COLOR = '#f6e05e'

// ─────────────────────────────────────────────────
// Composant principal
// ─────────────────────────────────────────────────

export default function GraphLayer() {
  const edgesGeoJSON = useAppStore((s) => s.edgesGeoJSON)
  const nodesGeoJSON = useAppStore((s) => s.nodesGeoJSON)
  const graphLoaded = useAppStore((s) => s.graphLoaded)
  const interactionMode = useAppStore((s) => s.interactionMode)

  const edgeStyle = useCallback((feature) => {
    const status = feature?.properties?.status || 'normal'
    const isInteractive =
      interactionMode === INTERACTION_MODE.BLOCK_ROAD ||
      interactionMode === INTERACTION_MODE.ADD_TRAFFIC

    return {
      color: EDGE_COLORS[status] || EDGE_COLORS.normal,
      weight: EDGE_WEIGHT[status] || EDGE_WEIGHT.normal,
      opacity: status === 'normal' ? 0.6 : 0.9,
      cursor: isInteractive ? 'pointer' : 'default',
    }
  }, [interactionMode])

  const onEachEdge = useCallback(
    (feature, layer) => {
      const props = feature?.properties || {}

      // Tooltip informatif
      if (props.name || props.highway) {
        layer.bindTooltip(
          `<div class="edge-tooltip">
            <strong>${props.name || 'Sans nom'}</strong><br/>
            ${props.highway} — ${props.length ? (props.length).toFixed(0) + 'm' : ''}<br/>
            ${props.speed_kph ? props.speed_kph + ' km/h' : ''}
            ${props.status !== 'normal' ? `<br/><span class="status-${props.status}">${props.status.toUpperCase()}</span>` : ''}
          </div>`,
          { sticky: true, className: 'crossflow-tooltip' }
        )
      }

      // Clic selon le mode — lecture dynamique du store pour éviter la capture de closure
      layer.on('click', (e) => {
        L.DomEvent.stopPropagation(e)
        const currentMode = useAppStore.getState().interactionMode
        const edgeId = feature?.properties?.id
        if (!edgeId) return
        if (currentMode === INTERACTION_MODE.BLOCK_ROAD) {
          useAppStore.getState().blockRoad(edgeId)
        } else if (currentMode === INTERACTION_MODE.ADD_TRAFFIC) {
          useAppStore.getState().addTraffic(edgeId)
        }
      })

      // Survol pour modes interactifs
      layer.on('mouseover', () => {
        const isInteractive =
          useAppStore.getState().interactionMode === INTERACTION_MODE.BLOCK_ROAD ||
          useAppStore.getState().interactionMode === INTERACTION_MODE.ADD_TRAFFIC
        if (isInteractive) {
          layer.setStyle({ weight: 5, opacity: 1 })
        }
      })
      layer.on('mouseout', () => {
        layer.setStyle(edgeStyle(feature))
      })
    },
    [edgeStyle]
  )

  // Clé de re-render quand les données changent
  const edgesKey = useMemo(
    () => edgesGeoJSON ? JSON.stringify(edgesGeoJSON.features?.length) + Date.now() : 'empty',
    [edgesGeoJSON]
  )

  if (!graphLoaded || !edgesGeoJSON) return null

  return (
    <>
      {/* Réseau routier */}
      <GeoJSON
        key={edgesKey}
        data={edgesGeoJSON}
        style={edgeStyle}
        onEachFeature={onEachEdge}
      />

      {/* Nœuds : feux + intersections */}
      {nodesGeoJSON?.features?.map((feature) => (
        <NodeMarker key={feature.properties.id} feature={feature} />
      ))}
    </>
  )
}

// ─────────────────────────────────────────────────
// Marqueur de nœud
// ─────────────────────────────────────────────────

function NodeMarker({ feature }) {
  const props = feature.properties
  const [lng, lat] = feature.geometry.coordinates

  // N'afficher que les nœuds notables à partir d'un certain zoom
  if (!props.is_traffic_signal && !props.is_crossing && props.street_count < 3) {
    return null
  }

  const color = props.is_traffic_signal
    ? SIGNAL_COLOR
    : props.is_crossing
    ? CROSSING_COLOR
    : INTERSECTION_COLOR

  const radius = props.is_traffic_signal ? 4 : props.street_count >= 4 ? 3 : 2

  return (
    <CircleMarker
      center={[lat, lng]}
      radius={radius}
      pathOptions={{
        fillColor: color,
        fillOpacity: 0.85,
        color: color,
        weight: 1,
      }}
    >
      {props.is_traffic_signal && (
        <Tooltip direction="top" offset={[0, -4]}>
          🚦 Feu de signalisation
        </Tooltip>
      )}
    </CircleMarker>
  )
}
