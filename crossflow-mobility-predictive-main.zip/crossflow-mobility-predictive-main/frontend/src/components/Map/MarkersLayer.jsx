/**
 * Crossflow Mobility — MarkersLayer
 * Marqueurs de départ, d'arrivée et d'événements.
 */

import { Marker, Popup, Circle } from 'react-leaflet'
import L from 'leaflet'
import useAppStore from '../../store/useAppStore'

// ─────────────────────────────────────────────────
// Icônes SVG inline (pas de dépendance externe)
// ─────────────────────────────────────────────────

function makeDivIcon(emoji, bgColor) {
  return L.divIcon({
    html: `<div style="
      background:${bgColor};
      border:2px solid #fff;
      border-radius:50%;
      width:28px;height:28px;
      display:flex;align-items:center;justify-content:center;
      font-size:14px;
      box-shadow:0 2px 8px rgba(0,0,0,0.5);
    ">${emoji}</div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
    className: '',
  })
}

const START_ICON = makeDivIcon('🟢', '#276749')
const END_ICON = makeDivIcon('🔴', '#742a2a')

const EVENT_ICONS = {
  accident: makeDivIcon('💥', '#c05621'),
  works: makeDivIcon('🚧', '#b7791f'),
  demonstration: makeDivIcon('📢', '#6b46c1'),
  administrative: makeDivIcon('🚫', '#c53030'),
}

// ─────────────────────────────────────────────────
// Composant
// ─────────────────────────────────────────────────

export default function MarkersLayer() {
  const startPoint = useAppStore((s) => s.startPoint)
  const endPoint = useAppStore((s) => s.endPoint)
  const events = useAppStore((s) => s.simulationState.events)

  return (
    <>
      {/* Point de départ */}
      {startPoint && (
        <Marker position={[startPoint.lat, startPoint.lng]} icon={START_ICON}>
          <Popup>
            <strong>Départ</strong><br />
            {startPoint.lat.toFixed(5)}, {startPoint.lng.toFixed(5)}
          </Popup>
        </Marker>
      )}

      {/* Point d'arrivée */}
      {endPoint && (
        <Marker position={[endPoint.lat, endPoint.lng]} icon={END_ICON}>
          <Popup>
            <strong>Arrivée</strong><br />
            {endPoint.lat.toFixed(5)}, {endPoint.lng.toFixed(5)}
          </Popup>
        </Marker>
      )}

      {/* Événements */}
      {events.map((evt) => (
        <EventMarker key={evt.id} event={evt} />
      ))}
    </>
  )
}

function EventMarker({ event }) {
  const { center, radius_m, event_type, label, type } = event
  const evtType = event_type || type
  const icon = EVENT_ICONS[evtType] || EVENT_ICONS.accident

  const circleColors = {
    accident: '#fc8181',
    works: '#f6ad55',
    demonstration: '#b794f4',
    administrative: '#fc8181',
  }

  return (
    <>
      {/* Cercle de rayon d'impact */}
      <Circle
        center={[center.lat, center.lng]}
        radius={radius_m || 200}
        pathOptions={{
          color: circleColors[evtType] || '#fc8181',
          fillColor: circleColors[evtType] || '#fc8181',
          fillOpacity: 0.12,
          weight: 1.5,
          dashArray: '4 4',
        }}
      />

      {/* Marqueur central */}
      <Marker position={[center.lat, center.lng]} icon={icon}>
        <Popup>
          <strong>{label || evtType}</strong><br />
          Rayon : {radius_m || 200} m<br />
          Routes impactées : {event.affected_edges?.length || 0}
        </Popup>
      </Marker>
    </>
  )
}
