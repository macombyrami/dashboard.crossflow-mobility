/**
 * Crossflow Mobility — RoutePanel
 * Panneau de sélection de départ/arrivée et affichage de l'itinéraire.
 */

import { Navigation, MapPin, Loader2, ArrowRight, RefreshCw, GitCompare } from 'lucide-react'
import useAppStore, { INTERACTION_MODE } from '../../store/useAppStore'

export default function RoutePanel() {
  const startPoint = useAppStore((s) => s.startPoint)
  const endPoint = useAppStore((s) => s.endPoint)
  const route = useAppStore((s) => s.route)
  const routeLoading = useAppStore((s) => s.routeLoading)
  const interactionMode = useAppStore((s) => s.interactionMode)
  const setInteractionMode = useAppStore((s) => s.setInteractionMode)
  const calculateRoute = useAppStore((s) => s.calculateRoute)
  const clearRoute = useAppStore((s) => s.clearRoute)
  const compareRoutes = useAppStore((s) => s.compareRoutes)
  const showComparison = useAppStore((s) => s.showComparison)
  const routeNormal = useAppStore((s) => s.routeNormal)
  const routeSimulated = useAppStore((s) => s.routeSimulated)

  const isSelectingStart = interactionMode === INTERACTION_MODE.SELECT_START
  const isSelectingEnd = interactionMode === INTERACTION_MODE.SELECT_END

  return (
    <div className="panel">
      <h3 className="panel-title">
        <Navigation size={16} />
        Navigation
      </h3>

      {/* Sélection des points */}
      <div className="point-selector">
        <PointButton
          label="Départ"
          icon="🟢"
          point={startPoint}
          active={isSelectingStart}
          onClick={() =>
            setInteractionMode(
              isSelectingStart ? INTERACTION_MODE.NONE : INTERACTION_MODE.SELECT_START
            )
          }
        />
        <ArrowRight size={14} className="point-arrow" />
        <PointButton
          label="Arrivée"
          icon="🔴"
          point={endPoint}
          active={isSelectingEnd}
          onClick={() =>
            setInteractionMode(
              isSelectingEnd ? INTERACTION_MODE.NONE : INTERACTION_MODE.SELECT_END
            )
          }
        />
      </div>

      {/* Actions */}
      <div className="btn-group">
        <button
          className="btn btn-primary"
          onClick={calculateRoute}
          disabled={!startPoint || !endPoint || routeLoading}
        >
          {routeLoading ? (
            <><Loader2 size={14} className="spin" /> Calcul...</>
          ) : (
            <><MapPin size={14} /> Calculer</>
          )}
        </button>

        <button
          className="btn btn-secondary"
          onClick={clearRoute}
          disabled={!route && !startPoint}
        >
          <RefreshCw size={14} />
        </button>
      </div>

      {/* Résultat de l'itinéraire */}
      {route && (
        <div className="route-result">
          <div className="route-stat">
            <span className="stat-label">Distance</span>
            <span className="stat-value">{formatDist(route.total_distance_m)}</span>
          </div>
          <div className="route-stat">
            <span className="stat-label">Durée</span>
            <span className="stat-value">{formatTime(route.total_time_s)}</span>
          </div>
          <div className="route-stat">
            <span className="stat-label">Segments</span>
            <span className="stat-value">{route.segments?.length}</span>
          </div>

          {/* Segments détail */}
          <div className="segments-list">
            {route.segments?.slice(0, 8).map((seg, i) => (
              <SegmentItem key={i} segment={seg} />
            ))}
            {route.segments?.length > 8 && (
              <p className="segments-more">
                +{route.segments.length - 8} segments supplémentaires
              </p>
            )}
          </div>

          {/* Bouton comparaison */}
          <button
            className="btn btn-ghost btn-sm"
            onClick={compareRoutes}
          >
            <GitCompare size={13} />
            Comparer avant / après simulation
          </button>
        </div>
      )}

      {/* Comparaison */}
      {showComparison && routeNormal && routeSimulated && (
        <ComparisonResult normal={routeNormal} simulated={routeSimulated} />
      )}
    </div>
  )
}

// ─────────────────────────────────────────────────
// Sous-composants
// ─────────────────────────────────────────────────

function PointButton({ label, icon, point, active, onClick }) {
  return (
    <button
      className={`point-btn ${active ? 'point-btn-active' : ''}`}
      onClick={onClick}
    >
      <span className="point-icon">{icon}</span>
      <span className="point-label">
        {point
          ? `${point.lat.toFixed(4)}, ${point.lng.toFixed(4)}`
          : `Définir ${label}`}
      </span>
    </button>
  )
}

function SegmentItem({ segment }) {
  const statusColors = {
    normal: 'var(--color-text-muted)',
    slow: 'var(--color-warning)',
    blocked: 'var(--color-danger)',
  }

  return (
    <div className="segment-item">
      <span
        className="segment-dot"
        style={{ backgroundColor: statusColors[segment.status] || statusColors.normal }}
      />
      <span className="segment-name">
        {segment.name || 'Sans nom'}
      </span>
      <span className="segment-dist">
        {segment.length < 1000
          ? `${Math.round(segment.length)}m`
          : `${(segment.length / 1000).toFixed(1)}km`}
      </span>
    </div>
  )
}

function ComparisonResult({ normal, simulated }) {
  const distDelta = simulated.total_distance_m - normal.total_distance_m
  const timeDelta = simulated.total_time_s - normal.total_time_s

  return (
    <div className="comparison-card">
      <h4 className="comparison-title">Comparaison</h4>
      <div className="comparison-row">
        <span className="comp-label">Normal</span>
        <span>{formatDist(normal.total_distance_m)} — {formatTime(normal.total_time_s)}</span>
      </div>
      <div className="comparison-row">
        <span className="comp-label">Simulé</span>
        <span>{formatDist(simulated.total_distance_m)} — {formatTime(simulated.total_time_s)}</span>
      </div>
      <div className="comparison-delta">
        <DeltaBadge value={distDelta} unit="m" label="distance" />
        <DeltaBadge value={timeDelta} unit="s" label="temps" />
      </div>
    </div>
  )
}

function DeltaBadge({ value, unit, label }) {
  const isPositive = value > 0
  const formatted = unit === 's'
    ? `${isPositive ? '+' : ''}${Math.round(value / 60)} min`
    : `${isPositive ? '+' : ''}${Math.round(value)} m`

  return (
    <span className={`delta-badge ${isPositive ? 'delta-worse' : 'delta-better'}`}>
      {formatted} {label}
    </span>
  )
}

// ─────────────────────────────────────────────────
// Formatters
// ─────────────────────────────────────────────────

function formatDist(m) {
  if (!m) return '—'
  return m >= 1000 ? `${(m / 1000).toFixed(2)} km` : `${Math.round(m)} m`
}

function formatTime(s) {
  if (!s) return '—'
  const min = Math.round(s / 60)
  if (min < 60) return `${min} min`
  const h = Math.floor(min / 60)
  const rem = min % 60
  return `${h}h ${rem}min`
}
