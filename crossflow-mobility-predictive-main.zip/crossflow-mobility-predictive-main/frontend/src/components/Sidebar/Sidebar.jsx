/**
 * Crossflow Mobility — Sidebar
 * Panneau latéral principal avec onglets.
 */

import { MapPin, Sliders, BarChart2, Loader2 } from 'lucide-react'
import useAppStore from '../../store/useAppStore'
import RoutePanel from './RoutePanel'
import SimulationPanel from './SimulationPanel'
import StatsPanel from './StatsPanel'

const TABS = [
  { id: 'route', label: 'Itinéraire', icon: MapPin },
  { id: 'simulation', label: 'Simulation', icon: Sliders },
  { id: 'analytics', label: 'Analytique', icon: BarChart2 },
]

export default function Sidebar() {
  const sidebarTab = useAppStore((s) => s.sidebarTab)
  const setSidebarTab = useAppStore((s) => s.setSidebarTab)
  const graphLoaded = useAppStore((s) => s.graphLoaded)
  const graphLoading = useAppStore((s) => s.graphLoading)
  const loadGraph = useAppStore((s) => s.loadGraph)

  return (
    <aside className="sidebar">
      {/* En-tête sidebar */}
      <div className="sidebar-header">
        <span className="sidebar-brand">Crossflow Mobility</span>
        <span className="sidebar-version">v1.0</span>
      </div>

      {/* Bouton de chargement du graphe */}
      {!graphLoaded && (
        <div className="graph-load-card">
          <p className="graph-load-text">
            Chargez le graphe routier de Gennevilliers pour démarrer.
          </p>
          <button
            className="btn btn-primary btn-full"
            onClick={() => loadGraph(false)}
            disabled={graphLoading}
          >
            {graphLoading ? (
              <>
                <Loader2 size={16} className="spin" />
                Chargement OSMnx...
              </>
            ) : (
              'Charger Gennevilliers'
            )}
          </button>
          {graphLoading && (
            <p className="graph-load-hint">
              Premier chargement : 30-90s selon la connexion.<br />
              Les suivants utilisent le cache local.
            </p>
          )}
        </div>
      )}

      {/* Onglets */}
      <nav className="sidebar-tabs">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            className={`tab-btn ${sidebarTab === id ? 'tab-active' : ''}`}
            onClick={() => setSidebarTab(id)}
            disabled={!graphLoaded && id !== 'analytics'}
          >
            <Icon size={15} />
            <span>{label}</span>
          </button>
        ))}
      </nav>

      {/* Contenu de l'onglet actif */}
      <div className="sidebar-content">
        {sidebarTab === 'route' && <RoutePanel />}
        {sidebarTab === 'simulation' && <SimulationPanel />}
        {sidebarTab === 'analytics' && <StatsPanel />}
      </div>
    </aside>
  )
}
