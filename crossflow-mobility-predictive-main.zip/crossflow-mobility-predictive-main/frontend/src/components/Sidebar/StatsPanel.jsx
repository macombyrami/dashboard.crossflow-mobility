/**
 * Crossflow Mobility — StatsPanel
 * Panneau analytique avec métriques globales du réseau.
 */

import { useEffect } from 'react'
import { RefreshCw } from 'lucide-react'
import useAppStore from '../../store/useAppStore'

export default function StatsPanel() {
  const analytics = useAppStore((s) => s.analytics)
  const graphStats = useAppStore((s) => s.graphStats)
  const graphLoaded = useAppStore((s) => s.graphLoaded)
  const fetchAnalytics = useAppStore((s) => s.fetchAnalytics)

  useEffect(() => {
    if (graphLoaded) fetchAnalytics()
  }, [graphLoaded, fetchAnalytics])

  if (!graphLoaded) {
    return (
      <div className="panel">
        <p className="empty-state">Chargez le graphe pour voir les statistiques.</p>
      </div>
    )
  }

  return (
    <div className="panel">
      <div className="panel-header-row">
        <h3 className="panel-title">Analytique réseau</h3>
        <button className="btn-icon" onClick={fetchAnalytics} title="Actualiser">
          <RefreshCw size={14} />
        </button>
      </div>

      {/* Graphe OSM */}
      {graphStats && (
        <section className="stats-section">
          <h4 className="stats-subtitle">Graphe OSM</h4>
          <div className="stats-grid">
            <StatCard label="Nœuds" value={graphStats.node_count?.toLocaleString()} color="blue" />
            <StatCard label="Segments" value={graphStats.edge_count?.toLocaleString()} color="blue" />
            <StatCard label="Intersections" value={analytics?.total_intersections?.toLocaleString() || '—'} color="indigo" />
            <StatCard label="Feux OSM" value={graphStats.traffic_signal_count?.toLocaleString()} color="green" note="données OSM" />
          </div>
        </section>
      )}

      {/* Simulation en cours */}
      {analytics && (
        <section className="stats-section">
          <h4 className="stats-subtitle">Simulation en cours</h4>
          <div className="stats-grid">
            <StatCard
              label="Routes bloquées"
              value={analytics.blocked_roads}
              color="red"
              alert={analytics.blocked_roads > 0}
            />
            <StatCard
              label="Routes ralenties"
              value={analytics.slow_roads}
              color="orange"
              alert={analytics.slow_roads > 0}
            />
            <StatCard
              label="Événements actifs"
              value={analytics.active_events}
              color="purple"
              alert={analytics.active_events > 0}
            />
            <StatCard
              label="Vitesse moy."
              value={`${analytics.average_speed_kph} km/h`}
              color="blue"
            />
          </div>
        </section>
      )}

      {/* Réseau */}
      {analytics && (
        <section className="stats-section">
          <h4 className="stats-subtitle">Couverture réseau</h4>
          <div className="stats-grid stats-grid-2">
            <StatCard
              label="Longueur totale"
              value={`${analytics.network_coverage_km} km`}
              color="teal"
            />
            <StatCard
              label="Routes totales"
              value={analytics.total_roads?.toLocaleString()}
              color="teal"
            />
          </div>
        </section>
      )}

      {/* Note sur la couverture OSM des feux */}
      <div className="stats-note">
        <p>
          <strong>Note :</strong> Les feux de signalisation affichés proviennent
          uniquement des données OSM réelles. La couverture OSM de Gennevilliers
          peut être partielle pour ce type d'équipement.
        </p>
      </div>
    </div>
  )
}

function StatCard({ label, value, color, note, alert }) {
  const colorClass = {
    blue: 'stat-card-blue',
    red: 'stat-card-red',
    orange: 'stat-card-orange',
    green: 'stat-card-green',
    indigo: 'stat-card-indigo',
    purple: 'stat-card-purple',
    teal: 'stat-card-teal',
  }[color] || 'stat-card-blue'

  return (
    <div className={`stat-card ${colorClass} ${alert ? 'stat-card-alert' : ''}`}>
      <div className="stat-card-value">{value ?? '—'}</div>
      <div className="stat-card-label">{label}</div>
      {note && <div className="stat-card-note">{note}</div>}
    </div>
  )
}
