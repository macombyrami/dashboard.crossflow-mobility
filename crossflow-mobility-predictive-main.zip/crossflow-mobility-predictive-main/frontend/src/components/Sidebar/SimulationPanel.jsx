/**
 * Crossflow Mobility — SimulationPanel
 * Panneau de contrôle de la simulation (blocages, trafic, événements).
 */

import { Ban, Car, Zap, Trash2, Download } from 'lucide-react'
import useAppStore, { INTERACTION_MODE } from '../../store/useAppStore'
import * as api from '../../services/api'

export default function SimulationPanel() {
  const interactionMode = useAppStore((s) => s.interactionMode)
  const setInteractionMode = useAppStore((s) => s.setInteractionMode)
  const trafficLevel = useAppStore((s) => s.trafficLevel)
  const setTrafficLevel = useAppStore((s) => s.setTrafficLevel)
  const eventType = useAppStore((s) => s.eventType)
  const setEventType = useAppStore((s) => s.setEventType)
  const eventRadius = useAppStore((s) => s.eventRadius)
  const setEventRadius = useAppStore((s) => s.setEventRadius)
  const simulationState = useAppStore((s) => s.simulationState)
  const resetSimulation = useAppStore((s) => s.resetSimulation)
  const unblockRoad = useAppStore((s) => s.unblockRoad)

  const isBlockMode = interactionMode === INTERACTION_MODE.BLOCK_ROAD
  const isTrafficMode = interactionMode === INTERACTION_MODE.ADD_TRAFFIC
  const isEventMode = interactionMode === INTERACTION_MODE.ADD_EVENT

  const handleExportGeoJSON = async () => {
    try {
      const data = await api.exportAffectedEdges()
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'crossflow_affected_edges.geojson'
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      console.error('Export error:', err)
    }
  }

  return (
    <div className="panel">
      {/* ── Blocage de routes ── */}
      <section className="sim-section">
        <h3 className="panel-title">
          <Ban size={16} />
          Bloquer des routes
        </h3>
        <p className="sim-hint">
          Activez le mode, puis cliquez sur un segment de la carte.
        </p>
        <button
          className={`btn btn-full ${isBlockMode ? 'btn-danger-active' : 'btn-danger'}`}
          onClick={() =>
            setInteractionMode(
              isBlockMode ? INTERACTION_MODE.NONE : INTERACTION_MODE.BLOCK_ROAD
            )
          }
        >
          <Ban size={14} />
          {isBlockMode ? 'Annuler le mode blocage' : 'Activer le mode blocage'}
        </button>

        {/* Liste des routes bloquées */}
        {simulationState.blocked_edges.length > 0 && (
          <div className="blocked-list">
            <p className="blocked-count">
              {simulationState.blocked_edges.length} route(s) bloquée(s)
            </p>
            {simulationState.blocked_edges.slice(0, 5).map((eid) => (
              <div key={eid} className="blocked-item">
                <span className="blocked-id">{truncateId(eid)}</span>
                <button
                  className="btn-icon btn-icon-sm"
                  onClick={() => unblockRoad(eid)}
                  title="Débloquer"
                >
                  ×
                </button>
              </div>
            ))}
            {simulationState.blocked_edges.length > 5 && (
              <p className="blocked-more">
                +{simulationState.blocked_edges.length - 5} autres
              </p>
            )}
          </div>
        )}
      </section>

      {/* ── Niveau de trafic ── */}
      <section className="sim-section">
        <h3 className="panel-title">
          <Car size={16} />
          Simuler du trafic
        </h3>
        <div className="traffic-levels">
          {TRAFFIC_LEVELS.map(({ value, label, color }) => (
            <button
              key={value}
              className={`traffic-btn ${trafficLevel === value ? 'traffic-active' : ''}`}
              style={{ '--traffic-color': color }}
              onClick={() => setTrafficLevel(value)}
            >
              {label}
            </button>
          ))}
        </div>
        <button
          className={`btn btn-full ${isTrafficMode ? 'btn-warning-active' : 'btn-warning'}`}
          onClick={() =>
            setInteractionMode(
              isTrafficMode ? INTERACTION_MODE.NONE : INTERACTION_MODE.ADD_TRAFFIC
            )
          }
        >
          <Car size={14} />
          {isTrafficMode ? 'Annuler le mode trafic' : 'Appliquer le trafic sur un segment'}
        </button>
      </section>

      {/* ── Événements ── */}
      <section className="sim-section">
        <h3 className="panel-title">
          <Zap size={16} />
          Créer un événement
        </h3>

        <div className="form-group">
          <label className="form-label">Type d'événement</label>
          <select
            className="form-select"
            value={eventType}
            onChange={(e) => setEventType(e.target.value)}
          >
            {EVENT_TYPES.map(({ value, label }) => (
              <option key={value} value={value}>{label}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label className="form-label">
            Rayon d'impact : <strong>{eventRadius} m</strong>
          </label>
          <input
            type="range"
            min={50}
            max={1000}
            step={50}
            value={eventRadius}
            onChange={(e) => setEventRadius(Number(e.target.value))}
            className="form-range"
          />
        </div>

        <button
          className={`btn btn-full ${isEventMode ? 'btn-purple-active' : 'btn-purple'}`}
          onClick={() =>
            setInteractionMode(
              isEventMode ? INTERACTION_MODE.NONE : INTERACTION_MODE.ADD_EVENT
            )
          }
        >
          <Zap size={14} />
          {isEventMode ? 'Annuler le placement' : 'Placer l\'événement sur la carte'}
        </button>

        {/* Liste des événements */}
        {simulationState.events?.length > 0 && (
          <div className="events-list">
            {simulationState.events.slice(0, 5).map((evt) => (
              <div key={evt.id} className="event-item">
                <span className="event-icon">{EVENT_ICONS[evt.event_type || evt.type]}</span>
                <span className="event-label">{evt.label}</span>
                <span className="event-count">{evt.affected_edges?.length || 0} routes</span>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* ── Actions globales ── */}
      <section className="sim-section sim-actions">
        <button
          className="btn btn-secondary btn-full"
          onClick={handleExportGeoJSON}
        >
          <Download size={14} />
          Exporter les segments impactés (GeoJSON)
        </button>
        <button
          className="btn btn-ghost btn-full"
          onClick={resetSimulation}
        >
          <Trash2 size={14} />
          Réinitialiser la simulation
        </button>
      </section>
    </div>
  )
}

// ─────────────────────────────────────────────────
// Constantes
// ─────────────────────────────────────────────────

const TRAFFIC_LEVELS = [
  { value: 'light', label: 'Léger ×1.2', color: '#f6e05e' },
  { value: 'medium', label: 'Moyen ×1.5', color: '#ed8936' },
  { value: 'heavy', label: 'Fort ×2.0', color: '#e53e3e' },
]

const EVENT_TYPES = [
  { value: 'accident', label: '💥 Accident' },
  { value: 'works', label: '🚧 Travaux' },
  { value: 'demonstration', label: '📢 Manifestation' },
  { value: 'administrative', label: '🚫 Fermeture administrative' },
]

const EVENT_ICONS = {
  accident: '💥',
  works: '🚧',
  demonstration: '📢',
  administrative: '🚫',
}

// ─────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────

function truncateId(id) {
  if (!id) return ''
  const parts = id.split('_')
  if (parts.length >= 2) {
    return `…${parts[0].slice(-4)}_${parts[1].slice(-4)}`
  }
  return id.slice(0, 12) + '…'
}
