/**
 * Crossflow Mobility — App
 * Composant racine : layout principal (sidebar + carte + barre supérieure).
 */

import { useEffect } from 'react'
import { Activity } from 'lucide-react'
import useAppStore from './store/useAppStore'
import Sidebar from './components/Sidebar/Sidebar'
import MapView from './components/Map/MapView'
import Notification from './components/UI/Notification'

export default function App() {
  const notification = useAppStore((s) => s.notification)
  const clearNotification = useAppStore((s) => s.clearNotification)
  const graphLoaded = useAppStore((s) => s.graphLoaded)
  const graphStats = useAppStore((s) => s.graphStats)

  // Auto-dismiss des notifications après 4 secondes
  useEffect(() => {
    if (!notification) return
    const t = setTimeout(clearNotification, 4000)
    return () => clearTimeout(t)
  }, [notification, clearNotification])

  return (
    <div className="app-layout">
      {/* ── Barre supérieure ── */}
      <header className="topbar">
        <div className="topbar-left">
          <Activity size={22} className="topbar-icon" />
          <span className="topbar-title">Crossflow Mobility</span>
          <span className="topbar-subtitle">Gennevilliers · Simulation de trafic</span>
        </div>

        <div className="topbar-right">
          {graphLoaded && graphStats ? (
            <div className="topbar-stats">
              <TopbarStat label="nœuds" value={graphStats.node_count?.toLocaleString()} />
              <TopbarStat label="segments" value={graphStats.edge_count?.toLocaleString()} />
              {graphStats.traffic_signal_count > 0 && (
                <TopbarStat label="feux" value={graphStats.traffic_signal_count} color="green" />
              )}
            </div>
          ) : (
            <span className="topbar-hint">Chargez le graphe pour démarrer</span>
          )}

          <div className={`status-dot ${graphLoaded ? 'status-ok' : 'status-idle'}`} />
        </div>
      </header>

      {/* ── Corps principal ── */}
      <div className="main-body">
        <Sidebar />
        <main className="map-area">
          <MapView />
        </main>
      </div>

      {/* ── Notification flottante ── */}
      {notification && (
        <Notification
          type={notification.type}
          message={notification.message}
          onClose={clearNotification}
        />
      )}
    </div>
  )
}

function TopbarStat({ label, value, color }) {
  return (
    <div className="topbar-stat">
      <span className={`topbar-stat-value ${color ? `topbar-stat-${color}` : ''}`}>{value}</span>
      <span className="topbar-stat-label">{label}</span>
    </div>
  )
}
