/**
 * Crossflow Mobility — Store global (Zustand)
 *
 * Gère l'état applicatif partagé entre la carte et le panneau latéral :
 *  - état du graphe (chargé, stats)
 *  - points de départ / arrivée
 *  - itinéraire calculé
 *  - comparaison avant/après
 *  - état de la simulation
 *  - mode d'interaction (select / block / traffic / event)
 *  - analytics
 */

import { create } from 'zustand'
import * as api from '../services/api'

// ─────────────────────────────────────────────────
// Types de mode d'interaction
// ─────────────────────────────────────────────────
export const INTERACTION_MODE = {
  SELECT_START: 'select_start',   // Clic = point de départ
  SELECT_END: 'select_end',       // Clic = point d'arrivée
  BLOCK_ROAD: 'block_road',       // Clic = bloquer un segment
  ADD_TRAFFIC: 'add_traffic',     // Clic = appliquer trafic
  ADD_EVENT: 'add_event',         // Clic = créer événement
  NONE: 'none',
}

const useAppStore = create((set, get) => ({
  // ── État du graphe
  graphLoaded: false,
  graphLoading: false,
  graphStats: null,

  // ── Points de navigation
  startPoint: null,   // { lat, lng }
  endPoint: null,     // { lat, lng }

  // ── Itinéraires
  route: null,        // RouteResponse
  routeNormal: null,  // Pour la comparaison
  routeSimulated: null,
  routeLoading: false,

  // ── Simulation
  simulationState: {
    blocked_edges: [],
    traffic_edges: {},
    events: [],
    affected_edges: [],
  },

  // ── Analytics
  analytics: null,

  // ── UI
  interactionMode: INTERACTION_MODE.NONE,
  trafficLevel: 'medium',        // Niveau de trafic à appliquer
  eventType: 'accident',         // Type d'événement à créer
  eventRadius: 200,              // Rayon en mètres
  sidebarTab: 'route',           // 'route' | 'simulation' | 'analytics'
  notification: null,            // { type: 'success'|'error'|'info', message }
  showComparison: false,
  edgesGeoJSON: null,            // GeoJSON de tous les edges (pour affichage carte)
  nodesGeoJSON: null,            // GeoJSON de tous les nœuds

  // ─────────────────────────────────────────────
  // Graphe
  // ─────────────────────────────────────────────

  loadGraph: async (forceReload = false) => {
    set({ graphLoading: true, notification: null })
    try {
      const result = await api.loadGraph(forceReload)
      set({
        graphLoaded: true,
        graphStats: result.stats,
        graphLoading: false,
        notification: {
          type: 'success',
          message: `Graphe chargé : ${result.stats.node_count} nœuds, ${result.stats.edge_count} segments`,
        },
      })
      // Charger les données géospatiales pour la carte
      get().fetchMapData()
    } catch (err) {
      set({
        graphLoading: false,
        notification: { type: 'error', message: `Erreur : ${err.message}` },
      })
    }
  },

  fetchMapData: async () => {
    try {
      const [edgesGJ, nodesGJ] = await Promise.all([
        api.getEdges('all'),
        api.getNodes(),
      ])
      set({ edgesGeoJSON: edgesGJ, nodesGeoJSON: nodesGJ })
    } catch (err) {
      console.warn('fetchMapData error:', err.message)
    }
  },

  refreshEdges: async () => {
    try {
      const edgesGJ = await api.getEdges('all')
      set({ edgesGeoJSON: edgesGJ })
    } catch (err) {
      console.warn('refreshEdges error:', err.message)
    }
  },

  // ─────────────────────────────────────────────
  // Navigation
  // ─────────────────────────────────────────────

  setStartPoint: (latlng) => set({ startPoint: latlng }),
  setEndPoint: (latlng) => set({ endPoint: latlng }),

  calculateRoute: async () => {
    const { startPoint, endPoint } = get()
    if (!startPoint || !endPoint) {
      set({ notification: { type: 'error', message: 'Sélectionnez un départ et une arrivée.' } })
      return
    }
    set({ routeLoading: true, notification: null })
    try {
      const result = await api.calculateRoute(startPoint, endPoint)
      set({
        route: result,
        routeLoading: false,
        notification: {
          type: 'success',
          message: `Itinéraire : ${(result.total_distance_m / 1000).toFixed(2)} km — ${Math.round(result.total_time_s / 60)} min`,
        },
      })
    } catch (err) {
      set({
        routeLoading: false,
        notification: { type: 'error', message: err.message },
      })
    }
  },

  compareRoutes: async () => {
    const { startPoint, endPoint } = get()
    if (!startPoint || !endPoint) return
    try {
      const result = await api.compareRoutes(startPoint, endPoint)
      set({
        routeNormal: result.normal,
        routeSimulated: result.simulated,
        showComparison: true,
      })
    } catch (err) {
      set({ notification: { type: 'error', message: err.message } })
    }
  },

  // ─────────────────────────────────────────────
  // Simulation
  // ─────────────────────────────────────────────

  blockRoad: async (edgeId) => {
    try {
      const result = await api.blockRoad(edgeId)
      set({ simulationState: result.state })
      get().refreshEdges()
      get().recalculateIfRoute()
    } catch (err) {
      set({ notification: { type: 'error', message: err.message } })
    }
  },

  unblockRoad: async (edgeId) => {
    try {
      const result = await api.unblockRoad(edgeId)
      set({ simulationState: result.state })
      get().refreshEdges()
      get().recalculateIfRoute()
    } catch (err) {
      set({ notification: { type: 'error', message: err.message } })
    }
  },

  addTraffic: async (edgeId) => {
    const { trafficLevel } = get()
    try {
      const result = await api.addTraffic(edgeId, trafficLevel)
      set({ simulationState: result.state })
      get().refreshEdges()
      get().recalculateIfRoute()
    } catch (err) {
      set({ notification: { type: 'error', message: err.message } })
    }
  },

  addEvent: async (center) => {
    const { eventType, eventRadius } = get()
    try {
      const result = await api.addEvent(center, eventRadius, eventType)
      set({
        simulationState: result.state,
        notification: {
          type: 'info',
          message: result.message,
        },
      })
      get().refreshEdges()
      get().recalculateIfRoute()
    } catch (err) {
      set({ notification: { type: 'error', message: err.message } })
    }
  },

  resetSimulation: async () => {
    try {
      await api.resetSimulation()
      set({
        simulationState: { blocked_edges: [], traffic_edges: {}, events: [], affected_edges: [] },
        route: null,
        routeNormal: null,
        routeSimulated: null,
        showComparison: false,
        notification: { type: 'info', message: 'Simulation réinitialisée.' },
      })
      get().refreshEdges()
    } catch (err) {
      set({ notification: { type: 'error', message: err.message } })
    }
  },

  fetchSimulationState: async () => {
    try {
      const state = await api.getSimulationState()
      set({ simulationState: state })
    } catch (_) {}
  },

  fetchAnalytics: async () => {
    try {
      const data = await api.getAnalytics()
      set({ analytics: data })
    } catch (_) {}
  },

  // ─────────────────────────────────────────────
  // Helpers
  // ─────────────────────────────────────────────

  recalculateIfRoute: () => {
    const { route } = get()
    if (route) get().calculateRoute()
  },

  setInteractionMode: (mode) => set({ interactionMode: mode }),
  setTrafficLevel: (level) => set({ trafficLevel: level }),
  setEventType: (type) => set({ eventType: type }),
  setEventRadius: (r) => set({ eventRadius: r }),
  setSidebarTab: (tab) => set({ sidebarTab: tab }),
  clearNotification: () => set({ notification: null }),
  clearRoute: () => set({ route: null, startPoint: null, endPoint: null }),
}))

export default useAppStore
