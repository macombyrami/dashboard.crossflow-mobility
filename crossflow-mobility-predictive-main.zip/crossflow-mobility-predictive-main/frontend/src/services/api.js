/**
 * Crossflow Mobility — Service API
 * Couche d'abstraction vers le backend FastAPI.
 */

import axios from 'axios'

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 120_000, // 120s pour le chargement OSMnx initial
  headers: { 'Content-Type': 'application/json' },
})

// Intercepteur pour les erreurs
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const detail =
      error?.response?.data?.detail ||
      error?.message ||
      'Erreur de connexion au backend'
    return Promise.reject(new Error(detail))
  }
)

// ─────────────────────────────────────────────────
// System
// ─────────────────────────────────────────────────

export const healthCheck = () =>
  api.get('/health').then((r) => r.data)

// ─────────────────────────────────────────────────
// Graph
// ─────────────────────────────────────────────────

export const loadGraph = (forceReload = false) =>
  api
    .post(`/graph/load-gennevilliers?force_reload=${forceReload}`)
    .then((r) => r.data)

export const getGraphStats = () =>
  api.get('/graph/stats').then((r) => r.data)

/**
 * Retourne les nœuds du graphe au format GeoJSON FeatureCollection.
 * @param {boolean} trafficSignalsOnly - seulement les feux
 * @param {boolean} intersectionsOnly - seulement les intersections
 */
export const getNodes = (trafficSignalsOnly = false, intersectionsOnly = false) =>
  api
    .get('/graph/nodes', {
      params: {
        traffic_signals_only: trafficSignalsOnly,
        intersections_only: intersectionsOnly,
      },
    })
    .then((r) => r.data)

/**
 * Retourne les edges du graphe au format GeoJSON FeatureCollection.
 * @param {string} statusFilter - 'all' | 'normal' | 'slow' | 'blocked'
 */
export const getEdges = (statusFilter = 'all') =>
  api
    .get('/graph/edges', { params: { status_filter: statusFilter } })
    .then((r) => r.data)

export const exportAffectedEdges = () =>
  api.get('/graph/export/edges-geojson').then((r) => r.data)

// ─────────────────────────────────────────────────
// Route
// ─────────────────────────────────────────────────

/**
 * Calcule un itinéraire entre deux points.
 * @param {{ lat, lng }} start
 * @param {{ lat, lng }} end
 * @param {string} weightMode - 'travel_time' | 'length'
 */
export const calculateRoute = (start, end, weightMode = 'travel_time') =>
  api
    .post('/route/calculate', { start, end, weight_mode: weightMode })
    .then((r) => r.data)

/**
 * Compare l'itinéraire normal vs simulé.
 */
export const compareRoutes = (start, end, weightMode = 'travel_time') =>
  api
    .post('/route/compare', { start, end, weight_mode: weightMode })
    .then((r) => r.data)

// ─────────────────────────────────────────────────
// Simulation
// ─────────────────────────────────────────────────

export const getSimulationState = () =>
  api.get('/simulation/state').then((r) => r.data)

export const resetSimulation = () =>
  api.post('/simulation/reset').then((r) => r.data)

export const blockRoad = (edgeId) =>
  api.post('/simulation/block-road', { edge_id: edgeId }).then((r) => r.data)

export const unblockRoad = (edgeId) =>
  api.post('/simulation/unblock-road', { edge_id: edgeId }).then((r) => r.data)

/**
 * Applique un niveau de trafic sur un segment.
 * @param {string} edgeId
 * @param {'light'|'medium'|'heavy'|'blocked'} level
 */
export const addTraffic = (edgeId, level) =>
  api
    .post('/simulation/add-traffic', { edge_id: edgeId, level })
    .then((r) => r.data)

export const removeTraffic = (edgeId) =>
  api.post('/simulation/remove-traffic', { edge_id: edgeId }).then((r) => r.data)

/**
 * Crée un événement localisé.
 * @param {{ lat, lng }} center
 * @param {number} radiusM - rayon d'impact en mètres
 * @param {'accident'|'works'|'demonstration'|'administrative'} eventType
 * @param {string|null} label
 */
export const addEvent = (center, radiusM, eventType, label = null) =>
  api
    .post('/simulation/add-event', {
      center,
      radius_m: radiusM,
      event_type: eventType,
      label,
    })
    .then((r) => r.data)

export const getAnalytics = () =>
  api.get('/simulation/analytics').then((r) => r.data)

export default api
