@echo off
REM ============================================================
REM  Crossflow Mobility — Script de démarrage (Windows)
REM ============================================================

setlocal EnableDelayedExpansion
set "ROOT=%~dp0"
set "ROOT=%ROOT:~0,-1%"
set "BACKEND_DIR=%ROOT%\backend"
set "FRONTEND_DIR=%ROOT%\frontend"
set "VENV_DIR=%ROOT%\.venv"
set "DATA_DIR=%ROOT%\data"

echo.
echo  ╔══════════════════════════════════════╗
echo  ║     Crossflow Mobility  v1.0         ║
echo  ║  Simulation trafic - Gennevilliers   ║
echo  ╚══════════════════════════════════════╝
echo.

REM ── Vérification Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERREUR] Python non trouve. Installez Python 3.10+
    echo https://www.python.org/downloads/
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('python --version') do echo [OK] %%v

REM ── Vérification Node
node --version >nul 2>&1
if errorlevel 1 (
    echo [ERREUR] Node.js non trouve. Installez Node.js 18+
    echo https://nodejs.org/
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('node --version') do echo [OK] Node.js %%v

REM ── Environnement virtuel Python
if not exist "%VENV_DIR%\Scripts\activate.bat" (
    echo [INFO] Creation de l'environnement virtuel Python...
    python -m venv "%VENV_DIR%"
)
call "%VENV_DIR%\Scripts\activate.bat"

REM ── Dépendances Python
python -c "import fastapi" >nul 2>&1
if errorlevel 1 (
    echo [INFO] Installation des dependances Python...
    pip install -q --upgrade pip
    pip install -q -r "%BACKEND_DIR%\requirements.txt"
    echo [OK] Dependances Python installees
) else (
    echo [OK] Dependances Python OK
)

REM ── Dépendances Node
if not exist "%FRONTEND_DIR%\node_modules" (
    echo [INFO] Installation des dependances Node.js...
    cd /d "%FRONTEND_DIR%"
    call npm install --silent
    cd /d "%ROOT%"
    echo [OK] Dependances Node installees
) else (
    echo [OK] Dependances Node OK
)

REM ── Pré-téléchargement du graphe
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%"
if not exist "%DATA_DIR%\gennevilliers_graph.pkl" (
    echo.
    echo [INFO] Graphe OSMnx absent - telechargement depuis OpenStreetMap...
    echo [INFO] 30-90 secondes selon la connexion
    cd /d "%ROOT%"
    set "PYTHONPATH=%ROOT%"
    python scripts\download_graph.py
    if errorlevel 1 (
        echo [ERREUR] Echec du telechargement du graphe.
        pause
        exit /b 1
    )
)

REM ── Démarrage du backend dans une nouvelle fenêtre
echo.
echo [INFO] Demarrage du backend FastAPI (port 8000)...
set "PYTHONPATH=%ROOT%"
start "Crossflow - Backend" cmd /k "cd /d "%ROOT%" && call "%VENV_DIR%\Scripts\activate.bat" && set PYTHONPATH=%ROOT% && python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload"

REM ── Attente que le backend soit prêt
echo [INFO] Attente du backend...
set /a WAITED=0
:WAIT_LOOP
timeout /t 2 /nobreak >nul
curl -s http://localhost:8000/health >nul 2>&1
if not errorlevel 1 goto BACKEND_READY
set /a WAITED+=2
if !WAITED! geq 30 (
    echo [ERREUR] Backend non repond apres 30 secondes.
    pause
    exit /b 1
)
goto WAIT_LOOP

:BACKEND_READY
echo [OK] Backend pret

REM ── Démarrage du frontend
echo [INFO] Demarrage du frontend Vite (port 5173)...
echo.
echo  ========================================
echo   Application :  http://localhost:5173
echo   API docs     :  http://localhost:8000/docs
echo   Fermez les fenetres cmd pour arreter
echo  ========================================
echo.

cd /d "%FRONTEND_DIR%"
start "Crossflow - Frontend" cmd /k "cd /d "%FRONTEND_DIR%" && npm run dev"

echo [OK] Les deux serveurs sont demarres.
echo Ouvrez http://localhost:5173 dans votre navigateur.
echo.
pause
