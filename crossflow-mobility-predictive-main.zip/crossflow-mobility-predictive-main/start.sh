#!/usr/bin/env bash
# ============================================================
#  Crossflow Mobility — Script de démarrage (Linux / macOS)
# ============================================================
set -e

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$ROOT/backend"
FRONTEND_DIR="$ROOT/frontend"
VENV_DIR="$ROOT/.venv"
DATA_DIR="$ROOT/data"

# ── Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

echo ""
echo -e "${CYAN}${BOLD}╔══════════════════════════════════════╗${NC}"
echo -e "${CYAN}${BOLD}║     Crossflow Mobility  v1.0         ║${NC}"
echo -e "${CYAN}${BOLD}║  Simulation trafic — Gennevilliers   ║${NC}"
echo -e "${CYAN}${BOLD}╚══════════════════════════════════════╝${NC}"
echo ""

# ── Vérification Python
if ! command -v python3 &>/dev/null; then
    echo -e "${RED}✗ Python 3 non trouvé. Installez Python 3.10+${NC}"
    exit 1
fi

PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo -e "${BLUE}▸ Python $PYTHON_VERSION${NC}"

# ── Vérification Node
if ! command -v node &>/dev/null; then
    echo -e "${RED}✗ Node.js non trouvé. Installez Node.js 18+${NC}"
    exit 1
fi

NODE_VERSION=$(node --version)
echo -e "${BLUE}▸ Node.js $NODE_VERSION${NC}"

# ── Environnement virtuel Python
if [ ! -d "$VENV_DIR" ]; then
    echo -e "${YELLOW}▸ Création de l'environnement virtuel Python...${NC}"
    python3 -m venv "$VENV_DIR"
fi

source "$VENV_DIR/bin/activate"

# ── Dépendances Python
if ! python -c "import fastapi" &>/dev/null 2>&1; then
    echo -e "${YELLOW}▸ Installation des dépendances Python...${NC}"
    pip install -q --upgrade pip
    pip install -q -r "$BACKEND_DIR/requirements.txt"
    echo -e "${GREEN}✓ Dépendances Python installées${NC}"
else
    echo -e "${GREEN}✓ Dépendances Python OK${NC}"
fi

# ── Dépendances Node
if [ ! -d "$FRONTEND_DIR/node_modules" ]; then
    echo -e "${YELLOW}▸ Installation des dépendances Node.js...${NC}"
    cd "$FRONTEND_DIR"
    npm install --silent
    cd "$ROOT"
    echo -e "${GREEN}✓ Dépendances Node installées${NC}"
else
    echo -e "${GREEN}✓ Dépendances Node OK${NC}"
fi

# ── Pré-téléchargement du graphe (si absent)
mkdir -p "$DATA_DIR"
if [ ! -f "$DATA_DIR/gennevilliers_graph.pkl" ]; then
    echo ""
    echo -e "${YELLOW}▸ Graphe OSMnx absent — téléchargement depuis OpenStreetMap...${NC}"
    echo -e "${YELLOW}  (30-90 secondes selon la connexion)${NC}"
    cd "$ROOT"
    python scripts/download_graph.py
fi

# ── Démarrage du backend (arrière-plan)
echo ""
echo -e "${BOLD}▸ Démarrage du backend FastAPI (port 8000)...${NC}"
cd "$ROOT"
PYTHONPATH="$ROOT" python -m uvicorn backend.main:app \
    --host 0.0.0.0 \
    --port 8000 \
    --reload \
    --log-level info &
BACKEND_PID=$!
echo -e "${GREEN}  Backend PID : $BACKEND_PID${NC}"

# ── Attente que le backend soit prêt
echo -e "${YELLOW}  Attente du backend...${NC}"
MAX_WAIT=30
WAITED=0
until curl -s http://localhost:8000/health >/dev/null 2>&1; do
    sleep 1
    WAITED=$((WAITED + 1))
    if [ "$WAITED" -ge "$MAX_WAIT" ]; then
        echo -e "${RED}  ✗ Backend non répondu après ${MAX_WAIT}s${NC}"
        kill $BACKEND_PID 2>/dev/null
        exit 1
    fi
done
echo -e "${GREEN}  ✓ Backend prêt${NC}"

# ── Démarrage du frontend (avant-plan)
echo -e "${BOLD}▸ Démarrage du frontend Vite (port 5173)...${NC}"
echo ""
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${CYAN}  Application :  http://localhost:5173${NC}"
echo -e "${CYAN}  API docs     :  http://localhost:8000/docs${NC}"
echo -e "${CYAN}  Appuyez sur Ctrl+C pour arrêter${NC}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# Nettoyage à l'arrêt
cleanup() {
    echo ""
    echo -e "${YELLOW}Arrêt des serveurs...${NC}"
    kill $BACKEND_PID 2>/dev/null
    echo -e "${GREEN}Au revoir !${NC}"
}
trap cleanup EXIT INT TERM

cd "$FRONTEND_DIR"
npm run dev
